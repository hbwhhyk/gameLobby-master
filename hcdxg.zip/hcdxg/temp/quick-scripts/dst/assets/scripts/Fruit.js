
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Fruit.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '365b4UAiQRBA7QXa2IuFMmj', 'Fruit');
// scripts/Fruit.js

"use strict";

// const Game = require("Game");
cc.Class({
  "extends": cc.Component,
  properties: {
    id: 0 // game: Game

  },
  init: function init(data) {
    this.id = data.id;
    var sp = this.node.getComponent(cc.Sprite);
    sp.spriteFrame = data.iconSF; // todo 控制一下每种水果的尺寸
  },
  start: function start() {},
  onBeginContact: function onBeginContact(contact, self, other) {
    // 貌似检测有点消耗性能
    if (self.node && other.node) {
      var s = self.node.getComponent('Fruit');
      var o = other.node.getComponent('Fruit');

      if (s && o && s.id === o.id) {
        self.node.emit('sameContact', {
          self: self,
          other: other
        });
      }
    }
  },
  update: function update() {
    // console.log(111)
    if (!this.node.getComponent(cc.RigidBody).awake && this.node.y >= cc.find("Canvas/xuxian").y) {
      cc.find("Canvas").getComponent("Game").gameover();
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRnJ1aXQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJpZCIsImluaXQiLCJkYXRhIiwic3AiLCJub2RlIiwiZ2V0Q29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJpY29uU0YiLCJzdGFydCIsIm9uQmVnaW5Db250YWN0IiwiY29udGFjdCIsInNlbGYiLCJvdGhlciIsInMiLCJvIiwiZW1pdCIsInVwZGF0ZSIsIlJpZ2lkQm9keSIsImF3YWtlIiwieSIsImZpbmQiLCJnYW1lb3ZlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUNMLFdBQVNELEVBQUUsQ0FBQ0UsU0FEUDtFQUdMQyxVQUFVLEVBQUU7SUFDUkMsRUFBRSxFQUFFLENBREksQ0FFUjs7RUFGUSxDQUhQO0VBT0xDLElBUEssZ0JBT0FDLElBUEEsRUFPTTtJQUNQLEtBQUtGLEVBQUwsR0FBVUUsSUFBSSxDQUFDRixFQUFmO0lBQ0EsSUFBTUcsRUFBRSxHQUFHLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QlQsRUFBRSxDQUFDVSxNQUExQixDQUFYO0lBQ0FILEVBQUUsQ0FBQ0ksV0FBSCxHQUFpQkwsSUFBSSxDQUFDTSxNQUF0QixDQUhPLENBSVA7RUFDSCxDQVpJO0VBYUxDLEtBYkssbUJBYUcsQ0FFUCxDQWZJO0VBZ0JMQyxjQWhCSywwQkFnQlVDLE9BaEJWLEVBZ0JtQkMsSUFoQm5CLEVBZ0J5QkMsS0FoQnpCLEVBZ0JnQztJQUNqQztJQUNBLElBQUlELElBQUksQ0FBQ1IsSUFBTCxJQUFhUyxLQUFLLENBQUNULElBQXZCLEVBQTZCO01BQ3pCLElBQU1VLENBQUMsR0FBR0YsSUFBSSxDQUFDUixJQUFMLENBQVVDLFlBQVYsQ0FBdUIsT0FBdkIsQ0FBVjtNQUNBLElBQU1VLENBQUMsR0FBR0YsS0FBSyxDQUFDVCxJQUFOLENBQVdDLFlBQVgsQ0FBd0IsT0FBeEIsQ0FBVjs7TUFDQSxJQUFJUyxDQUFDLElBQUlDLENBQUwsSUFBVUQsQ0FBQyxDQUFDZCxFQUFGLEtBQVNlLENBQUMsQ0FBQ2YsRUFBekIsRUFBNkI7UUFDekJZLElBQUksQ0FBQ1IsSUFBTCxDQUFVWSxJQUFWLENBQWUsYUFBZixFQUE4QjtVQUFFSixJQUFJLEVBQUpBLElBQUY7VUFBUUMsS0FBSyxFQUFMQTtRQUFSLENBQTlCO01BQ0g7SUFDSjtFQUNKLENBekJJO0VBMkJMSSxNQTNCSyxvQkEyQkk7SUFDTDtJQUNBLElBQUksQ0FBQyxLQUFLYixJQUFMLENBQVVDLFlBQVYsQ0FBdUJULEVBQUUsQ0FBQ3NCLFNBQTFCLEVBQXFDQyxLQUF0QyxJQUErQyxLQUFLZixJQUFMLENBQVVnQixDQUFWLElBQWV4QixFQUFFLENBQUN5QixJQUFILENBQVEsZUFBUixFQUF5QkQsQ0FBM0YsRUFBOEY7TUFDMUZ4QixFQUFFLENBQUN5QixJQUFILENBQVEsUUFBUixFQUFrQmhCLFlBQWxCLENBQStCLE1BQS9CLEVBQXVDaUIsUUFBdkM7SUFDSDtFQUNKO0FBaENJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxuLy8gY29uc3QgR2FtZSA9IHJlcXVpcmUoXCJHYW1lXCIpO1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgaWQ6IDAsXG4gICAgICAgIC8vIGdhbWU6IEdhbWVcbiAgICB9LFxuICAgIGluaXQoZGF0YSkge1xuICAgICAgICB0aGlzLmlkID0gZGF0YS5pZFxuICAgICAgICBjb25zdCBzcCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgc3Auc3ByaXRlRnJhbWUgPSBkYXRhLmljb25TRjtcbiAgICAgICAgLy8gdG9kbyDmjqfliLbkuIDkuIvmr4/np43msLTmnpznmoTlsLrlr7hcbiAgICB9LFxuICAgIHN0YXJ0KCkge1xuXG4gICAgfSxcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikge1xuICAgICAgICAvLyDosozkvLzmo4DmtYvmnInngrnmtojogJfmgKfog71cbiAgICAgICAgaWYgKHNlbGYubm9kZSAmJiBvdGhlci5ub2RlKSB7XG4gICAgICAgICAgICBjb25zdCBzID0gc2VsZi5ub2RlLmdldENvbXBvbmVudCgnRnJ1aXQnKTtcbiAgICAgICAgICAgIGNvbnN0IG8gPSBvdGhlci5ub2RlLmdldENvbXBvbmVudCgnRnJ1aXQnKTtcbiAgICAgICAgICAgIGlmIChzICYmIG8gJiYgcy5pZCA9PT0gby5pZCkge1xuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5lbWl0KCdzYW1lQ29udGFjdCcsIHsgc2VsZiwgb3RoZXIgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgdXBkYXRlKCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZygxMTEpXG4gICAgICAgIGlmICghdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5SaWdpZEJvZHkpLmF3YWtlICYmIHRoaXMubm9kZS55ID49IGNjLmZpbmQoXCJDYW52YXMveHV4aWFuXCIpLnkpIHtcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXNcIikuZ2V0Q29tcG9uZW50KFwiR2FtZVwiKS5nYW1lb3ZlcigpO1xuICAgICAgICB9XG4gICAgfVxufSk7XG4iXX0=