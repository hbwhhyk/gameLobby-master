
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Over.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8208cLeoTtKxIVX6aTTYYxC', 'Over');
// scripts/Over.js

"use strict";

var Game = require("Game");

cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    best: cc.Label,
    score: cc.Label,
    game: Game
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad() {
  // },
  start: function start() {
    this.showScore();
  },
  onBtnClick: function onBtnClick() {
    cc.director.loadScene("game");
  },
  showScore: function showScore() {
    this.score.string = "Score:" + this.game.scoreNum;
    var bestScore = Number(cc.sys.localStorage.getItem('hcdxg'));

    if (!bestScore) {
      this.best.string = "Best:" + this.game.scoreNum;
      cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
    } else {
      if (bestScore < this.game.scoreNum) {
        this.best.string = "Best:" + this.game.scoreNum;
        cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
      } else {
        this.best.string = "Best:" + bestScore;
      }
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcT3Zlci5qcyJdLCJuYW1lcyI6WyJHYW1lIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYmVzdCIsIkxhYmVsIiwic2NvcmUiLCJnYW1lIiwic3RhcnQiLCJzaG93U2NvcmUiLCJvbkJ0bkNsaWNrIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJzdHJpbmciLCJzY29yZU51bSIsImJlc3RTY29yZSIsIk51bWJlciIsInN5cyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzZXRJdGVtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQU1BLElBQUksR0FBR0MsT0FBTyxDQUFDLE1BQUQsQ0FBcEI7O0FBRUFDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ0wsV0FBU0QsRUFBRSxDQUFDRSxTQURQO0VBR0xDLFVBQVUsRUFBRTtJQUNSO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUVBQyxJQUFJLEVBQUVKLEVBQUUsQ0FBQ0ssS0FqQkQ7SUFrQlJDLEtBQUssRUFBRU4sRUFBRSxDQUFDSyxLQWxCRjtJQW9CUkUsSUFBSSxFQUFFVDtFQXBCRSxDQUhQO0VBMEJMO0VBRUE7RUFFQTtFQUVBVSxLQWhDSyxtQkFnQ0c7SUFFSixLQUFLQyxTQUFMO0VBQ0gsQ0FuQ0k7RUFxQ0xDLFVBckNLLHdCQXFDUTtJQUNUVixFQUFFLENBQUNXLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtFQUNILENBdkNJO0VBeUNMSCxTQXpDSyx1QkF5Q087SUFDUixLQUFLSCxLQUFMLENBQVdPLE1BQVgsY0FBNkIsS0FBS04sSUFBTCxDQUFVTyxRQUF2QztJQUNBLElBQUlDLFNBQVMsR0FBR0MsTUFBTSxDQUFDaEIsRUFBRSxDQUFDaUIsR0FBSCxDQUFPQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QixPQUE1QixDQUFELENBQXRCOztJQUNBLElBQUksQ0FBQ0osU0FBTCxFQUFnQjtNQUNaLEtBQUtYLElBQUwsQ0FBVVMsTUFBVixhQUEyQixLQUFLTixJQUFMLENBQVVPLFFBQXJDO01BQ0FkLEVBQUUsQ0FBQ2lCLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkUsT0FBcEIsQ0FBNEIsT0FBNUIsRUFBcUMsS0FBS2IsSUFBTCxDQUFVTyxRQUEvQztJQUNILENBSEQsTUFHTztNQUNILElBQUlDLFNBQVMsR0FBRyxLQUFLUixJQUFMLENBQVVPLFFBQTFCLEVBQW9DO1FBQ2hDLEtBQUtWLElBQUwsQ0FBVVMsTUFBVixhQUEyQixLQUFLTixJQUFMLENBQVVPLFFBQXJDO1FBQ0FkLEVBQUUsQ0FBQ2lCLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkUsT0FBcEIsQ0FBNEIsT0FBNUIsRUFBcUMsS0FBS2IsSUFBTCxDQUFVTyxRQUEvQztNQUNILENBSEQsTUFHTztRQUNILEtBQUtWLElBQUwsQ0FBVVMsTUFBVixhQUEyQkUsU0FBM0I7TUFDSDtJQUNKO0VBQ0osQ0F2REksQ0F5REw7O0FBekRLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IEdhbWUgPSByZXF1aXJlKFwiR2FtZVwiKTtcblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgICAvLyBBVFRSSUJVVEVTOlxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIGJhcjoge1xuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gdGhpcy5fYmFyO1xuICAgICAgICAvLyAgICAgfSxcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9iYXIgPSB2YWx1ZTtcbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gfSxcblxuICAgICAgICBiZXN0OiBjYy5MYWJlbCxcbiAgICAgICAgc2NvcmU6IGNjLkxhYmVsLFxuXG4gICAgICAgIGdhbWU6IEdhbWVcbiAgICB9LFxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICAvLyBvbkxvYWQoKSB7XG5cbiAgICAvLyB9LFxuXG4gICAgc3RhcnQoKSB7XG5cbiAgICAgICAgdGhpcy5zaG93U2NvcmUoKTtcbiAgICB9LFxuXG4gICAgb25CdG5DbGljaygpIHtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiZ2FtZVwiKTtcbiAgICB9LFxuXG4gICAgc2hvd1Njb3JlKCkge1xuICAgICAgICB0aGlzLnNjb3JlLnN0cmluZyA9IGBTY29yZToke3RoaXMuZ2FtZS5zY29yZU51bX1gO1xuICAgICAgICBsZXQgYmVzdFNjb3JlID0gTnVtYmVyKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaGNkeGcnKSk7XG4gICAgICAgIGlmICghYmVzdFNjb3JlKSB7XG4gICAgICAgICAgICB0aGlzLmJlc3Quc3RyaW5nID0gYEJlc3Q6JHt0aGlzLmdhbWUuc2NvcmVOdW19YDtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaGNkeGcnLCB0aGlzLmdhbWUuc2NvcmVOdW0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGJlc3RTY29yZSA8IHRoaXMuZ2FtZS5zY29yZU51bSkge1xuICAgICAgICAgICAgICAgIHRoaXMuYmVzdC5zdHJpbmcgPSBgQmVzdDoke3RoaXMuZ2FtZS5zY29yZU51bX1gO1xuICAgICAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaGNkeGcnLCB0aGlzLmdhbWUuc2NvcmVOdW0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJlc3Quc3RyaW5nID0gYEJlc3Q6JHtiZXN0U2NvcmV9YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=