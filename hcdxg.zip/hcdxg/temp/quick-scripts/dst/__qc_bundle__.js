
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/Fruit');
require('./assets/scripts/Game');
require('./assets/scripts/Juice');
require('./assets/scripts/Load');
require('./assets/scripts/Over');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Juice.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '56c1eHSOMxI0L+m6MX8FMXw', 'Juice');
// scripts/Juice.js

"use strict";

var RandomInteger = function RandomInteger(e, t) {
  return Math.floor(Math.random() * (t - e) + e);
};

cc.Class({
  "extends": cc.Component,
  properties: {
    particle: {
      "default": null,
      type: cc.SpriteFrame
    },
    circle: {
      "default": null,
      type: cc.SpriteFrame
    },
    slash: {
      "default": null,
      type: cc.SpriteFrame
    }
  },
  init: function init(data) {
    if (!data) {
      return;
    }

    ; // console.log(data);

    this.particle = data.particle;
    this.circle = data.particle;
    this.slash = data.slash;
  },
  // 合并时的动画效果
  showJuice: function showJuice(pos, width) {
    var _this = this;

    var _loop = function _loop(i) {
      var node = new cc.Node('Sprite');
      var sp = node.addComponent(cc.Sprite);
      sp.spriteFrame = _this.particle;
      node.parent = _this.node;
      var a = 359 * Math.random(),
          i = 30 * Math.random() + width / 2,
          l = cc.v2(Math.sin(a * Math.PI / 180) * i, Math.cos(a * Math.PI / 180) * i);
      node.scale = .5 * Math.random() + width / 100;
      var p = .5 * Math.random();
      node.position = pos;
      node.runAction(cc.sequence(cc.spawn(cc.moveBy(p, l), cc.scaleTo(p + .5, .3), cc.rotateBy(p + .5, RandomInteger(-360, 360))), cc.fadeOut(.1), cc.callFunc(function () {
        node.active = false;
      }, _this)));
    };

    // 果粒
    for (var i = 0; i < 10; ++i) {
      _loop(i);
    } // 水珠


    var _loop2 = function _loop2(f) {
      var node = new cc.Node('Sprite');
      var sp = node.addComponent(cc.Sprite);
      sp.spriteFrame = _this.circle;
      node.parent = _this.node;
      var a = 359 * Math.random(),
          i = 30 * Math.random() + width / 2,
          l = cc.v2(Math.sin(a * Math.PI / 180) * i, Math.cos(a * Math.PI / 180) * i);
      node.scale = .5 * Math.random() + width / 100;
      var p = .5 * Math.random();
      node.position = pos;
      node.runAction(cc.sequence(cc.spawn(cc.moveBy(p, l), cc.scaleTo(p + .5, .3)), cc.fadeOut(.1), cc.callFunc(function () {
        node.active = false;
      }, _this)));
    };

    for (var f = 0; f < 20; f++) {
      _loop2(f);
    } // 果汁


    var node = new cc.Node('Sprite');
    var sp = node.addComponent(cc.Sprite);
    sp.spriteFrame = this.slash;
    node.parent = this.node;
    node.position = pos;
    node.scale = 0;
    node.angle = RandomInteger(0, 360);
    node.runAction(cc.sequence(cc.spawn(cc.scaleTo(.2, width / 150), cc.fadeOut(1)), cc.callFunc(function () {
      node.active = false;
    })));
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcSnVpY2UuanMiXSwibmFtZXMiOlsiUmFuZG9tSW50ZWdlciIsImUiLCJ0IiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwYXJ0aWNsZSIsInR5cGUiLCJTcHJpdGVGcmFtZSIsImNpcmNsZSIsInNsYXNoIiwiaW5pdCIsImRhdGEiLCJzaG93SnVpY2UiLCJwb3MiLCJ3aWR0aCIsImkiLCJub2RlIiwiTm9kZSIsInNwIiwiYWRkQ29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJwYXJlbnQiLCJhIiwibCIsInYyIiwic2luIiwiUEkiLCJjb3MiLCJzY2FsZSIsInAiLCJwb3NpdGlvbiIsInJ1bkFjdGlvbiIsInNlcXVlbmNlIiwic3Bhd24iLCJtb3ZlQnkiLCJzY2FsZVRvIiwicm90YXRlQnkiLCJmYWRlT3V0IiwiY2FsbEZ1bmMiLCJhY3RpdmUiLCJmIiwiYW5nbGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBTUEsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7RUFDbEMsT0FBT0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxNQUFpQkgsQ0FBQyxHQUFHRCxDQUFyQixJQUEwQkEsQ0FBckMsQ0FBUDtBQUNILENBRkQ7O0FBSUFLLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ0wsV0FBU0QsRUFBRSxDQUFDRSxTQURQO0VBR0xDLFVBQVUsRUFBRTtJQUNSQyxRQUFRLEVBQUU7TUFDTixXQUFTLElBREg7TUFFTkMsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkgsQ0FERjtJQUtSQyxNQUFNLEVBQUU7TUFDSixXQUFTLElBREw7TUFFSkYsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkwsQ0FMQTtJQVNSRSxLQUFLLEVBQUU7TUFDSCxXQUFTLElBRE47TUFFSEgsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRk47RUFUQyxDQUhQO0VBa0JMRyxJQWxCSyxnQkFrQkFDLElBbEJBLEVBa0JNO0lBQ1AsSUFBSSxDQUFDQSxJQUFMLEVBQVc7TUFBRTtJQUFROztJQUFBLENBRGQsQ0FFUDs7SUFDQSxLQUFLTixRQUFMLEdBQWdCTSxJQUFJLENBQUNOLFFBQXJCO0lBQ0EsS0FBS0csTUFBTCxHQUFjRyxJQUFJLENBQUNOLFFBQW5CO0lBQ0EsS0FBS0ksS0FBTCxHQUFhRSxJQUFJLENBQUNGLEtBQWxCO0VBQ0gsQ0F4Qkk7RUEwQkw7RUFDQUcsU0EzQksscUJBMkJLQyxHQTNCTCxFQTJCVUMsS0EzQlYsRUEyQmlCO0lBQUE7O0lBQUEsMkJBRVRDLENBRlM7TUFHZCxJQUFNQyxJQUFJLEdBQUcsSUFBSWYsRUFBRSxDQUFDZ0IsSUFBUCxDQUFZLFFBQVosQ0FBYjtNQUNBLElBQU1DLEVBQUUsR0FBR0YsSUFBSSxDQUFDRyxZQUFMLENBQWtCbEIsRUFBRSxDQUFDbUIsTUFBckIsQ0FBWDtNQUVBRixFQUFFLENBQUNHLFdBQUgsR0FBaUIsS0FBSSxDQUFDaEIsUUFBdEI7TUFDQVcsSUFBSSxDQUFDTSxNQUFMLEdBQWMsS0FBSSxDQUFDTixJQUFuQjtNQUVBLElBQU1PLENBQUMsR0FBRyxNQUFNekIsSUFBSSxDQUFDRSxNQUFMLEVBQWhCO01BQUEsSUFDSWUsQ0FBQyxHQUFHLEtBQUtqQixJQUFJLENBQUNFLE1BQUwsRUFBTCxHQUFxQmMsS0FBSyxHQUFHLENBRHJDO01BQUEsSUFFSVUsQ0FBQyxHQUFHdkIsRUFBRSxDQUFDd0IsRUFBSCxDQUFNM0IsSUFBSSxDQUFDNEIsR0FBTCxDQUFTSCxDQUFDLEdBQUd6QixJQUFJLENBQUM2QixFQUFULEdBQWMsR0FBdkIsSUFBOEJaLENBQXBDLEVBQXVDakIsSUFBSSxDQUFDOEIsR0FBTCxDQUFTTCxDQUFDLEdBQUd6QixJQUFJLENBQUM2QixFQUFULEdBQWMsR0FBdkIsSUFBOEJaLENBQXJFLENBRlI7TUFHQUMsSUFBSSxDQUFDYSxLQUFMLEdBQWEsS0FBSy9CLElBQUksQ0FBQ0UsTUFBTCxFQUFMLEdBQXFCYyxLQUFLLEdBQUcsR0FBMUM7TUFDQSxJQUFNZ0IsQ0FBQyxHQUFHLEtBQUtoQyxJQUFJLENBQUNFLE1BQUwsRUFBZjtNQUVBZ0IsSUFBSSxDQUFDZSxRQUFMLEdBQWdCbEIsR0FBaEI7TUFDQUcsSUFBSSxDQUFDZ0IsU0FBTCxDQUNJL0IsRUFBRSxDQUFDZ0MsUUFBSCxDQUFZaEMsRUFBRSxDQUFDaUMsS0FBSCxDQUFTakMsRUFBRSxDQUFDa0MsTUFBSCxDQUFVTCxDQUFWLEVBQWFOLENBQWIsQ0FBVCxFQUNSdkIsRUFBRSxDQUFDbUMsT0FBSCxDQUFXTixDQUFDLEdBQUcsRUFBZixFQUFtQixFQUFuQixDQURRLEVBRVI3QixFQUFFLENBQUNvQyxRQUFILENBQVlQLENBQUMsR0FBRyxFQUFoQixFQUFvQm5DLGFBQWEsQ0FBQyxDQUFDLEdBQUYsRUFBTyxHQUFQLENBQWpDLENBRlEsQ0FBWixFQUdJTSxFQUFFLENBQUNxQyxPQUFILENBQVcsRUFBWCxDQUhKLEVBSUlyQyxFQUFFLENBQUNzQyxRQUFILENBQVksWUFBWTtRQUNwQnZCLElBQUksQ0FBQ3dCLE1BQUwsR0FBYyxLQUFkO01BQ0gsQ0FGRCxFQUVHLEtBRkgsQ0FKSixDQURKO0lBaEJjOztJQUNsQjtJQUNBLEtBQUssSUFBSXpCLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsRUFBcEIsRUFBd0IsRUFBRUEsQ0FBMUIsRUFBNkI7TUFBQSxNQUFwQkEsQ0FBb0I7SUF1QjVCLENBekJpQixDQTJCbEI7OztJQTNCa0IsNkJBNEJUMEIsQ0E1QlM7TUE2QmQsSUFBTXpCLElBQUksR0FBRyxJQUFJZixFQUFFLENBQUNnQixJQUFQLENBQVksUUFBWixDQUFiO01BQ0EsSUFBTUMsRUFBRSxHQUFHRixJQUFJLENBQUNHLFlBQUwsQ0FBa0JsQixFQUFFLENBQUNtQixNQUFyQixDQUFYO01BRUFGLEVBQUUsQ0FBQ0csV0FBSCxHQUFpQixLQUFJLENBQUNiLE1BQXRCO01BQ0FRLElBQUksQ0FBQ00sTUFBTCxHQUFjLEtBQUksQ0FBQ04sSUFBbkI7TUFFQSxJQUFJTyxDQUFDLEdBQUcsTUFBTXpCLElBQUksQ0FBQ0UsTUFBTCxFQUFkO01BQUEsSUFBNkJlLENBQUMsR0FBRyxLQUFLakIsSUFBSSxDQUFDRSxNQUFMLEVBQUwsR0FBcUJjLEtBQUssR0FBRyxDQUE5RDtNQUFBLElBQ0lVLENBQUMsR0FBR3ZCLEVBQUUsQ0FBQ3dCLEVBQUgsQ0FBTTNCLElBQUksQ0FBQzRCLEdBQUwsQ0FBU0gsQ0FBQyxHQUFHekIsSUFBSSxDQUFDNkIsRUFBVCxHQUFjLEdBQXZCLElBQThCWixDQUFwQyxFQUF1Q2pCLElBQUksQ0FBQzhCLEdBQUwsQ0FBU0wsQ0FBQyxHQUFHekIsSUFBSSxDQUFDNkIsRUFBVCxHQUFjLEdBQXZCLElBQThCWixDQUFyRSxDQURSO01BRUFDLElBQUksQ0FBQ2EsS0FBTCxHQUFhLEtBQUsvQixJQUFJLENBQUNFLE1BQUwsRUFBTCxHQUFxQmMsS0FBSyxHQUFHLEdBQTFDO01BQ0EsSUFBSWdCLENBQUMsR0FBRyxLQUFLaEMsSUFBSSxDQUFDRSxNQUFMLEVBQWI7TUFDQWdCLElBQUksQ0FBQ2UsUUFBTCxHQUFnQmxCLEdBQWhCO01BQ0FHLElBQUksQ0FBQ2dCLFNBQUwsQ0FBZS9CLEVBQUUsQ0FBQ2dDLFFBQUgsQ0FBWWhDLEVBQUUsQ0FBQ2lDLEtBQUgsQ0FBU2pDLEVBQUUsQ0FBQ2tDLE1BQUgsQ0FBVUwsQ0FBVixFQUFhTixDQUFiLENBQVQsRUFBMEJ2QixFQUFFLENBQUNtQyxPQUFILENBQVdOLENBQUMsR0FBRyxFQUFmLEVBQW1CLEVBQW5CLENBQTFCLENBQVosRUFBK0Q3QixFQUFFLENBQUNxQyxPQUFILENBQVcsRUFBWCxDQUEvRCxFQUErRXJDLEVBQUUsQ0FBQ3NDLFFBQUgsQ0FBWSxZQUFZO1FBQ2xIdkIsSUFBSSxDQUFDd0IsTUFBTCxHQUFjLEtBQWQ7TUFDSCxDQUY2RixFQUUzRixLQUYyRixDQUEvRSxDQUFmO0lBeENjOztJQTRCbEIsS0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEVBQXBCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQTZCO01BQUEsT0FBcEJBLENBQW9CO0lBZTVCLENBM0NpQixDQTZDbEI7OztJQUNBLElBQU16QixJQUFJLEdBQUcsSUFBSWYsRUFBRSxDQUFDZ0IsSUFBUCxDQUFZLFFBQVosQ0FBYjtJQUNBLElBQU1DLEVBQUUsR0FBR0YsSUFBSSxDQUFDRyxZQUFMLENBQWtCbEIsRUFBRSxDQUFDbUIsTUFBckIsQ0FBWDtJQUVBRixFQUFFLENBQUNHLFdBQUgsR0FBaUIsS0FBS1osS0FBdEI7SUFDQU8sSUFBSSxDQUFDTSxNQUFMLEdBQWMsS0FBS04sSUFBbkI7SUFFQUEsSUFBSSxDQUFDZSxRQUFMLEdBQWdCbEIsR0FBaEI7SUFDQUcsSUFBSSxDQUFDYSxLQUFMLEdBQWEsQ0FBYjtJQUNBYixJQUFJLENBQUMwQixLQUFMLEdBQWEvQyxhQUFhLENBQUMsQ0FBRCxFQUFJLEdBQUosQ0FBMUI7SUFDQXFCLElBQUksQ0FBQ2dCLFNBQUwsQ0FBZS9CLEVBQUUsQ0FBQ2dDLFFBQUgsQ0FBWWhDLEVBQUUsQ0FBQ2lDLEtBQUgsQ0FBU2pDLEVBQUUsQ0FBQ21DLE9BQUgsQ0FBVyxFQUFYLEVBQWV0QixLQUFLLEdBQUcsR0FBdkIsQ0FBVCxFQUFzQ2IsRUFBRSxDQUFDcUMsT0FBSCxDQUFXLENBQVgsQ0FBdEMsQ0FBWixFQUFrRXJDLEVBQUUsQ0FBQ3NDLFFBQUgsQ0FBWSxZQUFZO01BQ3JHdkIsSUFBSSxDQUFDd0IsTUFBTCxHQUFjLEtBQWQ7SUFDSCxDQUZnRixDQUFsRSxDQUFmO0VBR0g7QUFyRkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgUmFuZG9tSW50ZWdlciA9IGZ1bmN0aW9uIChlLCB0KSB7XG4gICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqICh0IC0gZSkgKyBlKTtcbn1cblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcGFydGljbGU6IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBjaXJjbGU6IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzbGFzaDoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgaW5pdChkYXRhKSB7XG4gICAgICAgIGlmICghZGF0YSkgeyByZXR1cm4gfTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coZGF0YSk7XG4gICAgICAgIHRoaXMucGFydGljbGUgPSBkYXRhLnBhcnRpY2xlO1xuICAgICAgICB0aGlzLmNpcmNsZSA9IGRhdGEucGFydGljbGU7XG4gICAgICAgIHRoaXMuc2xhc2ggPSBkYXRhLnNsYXNoO1xuICAgIH0sXG5cbiAgICAvLyDlkIjlubbml7bnmoTliqjnlLvmlYjmnpxcbiAgICBzaG93SnVpY2UocG9zLCB3aWR0aCkge1xuICAgICAgICAvLyDmnpznspJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgKytpKSB7XG4gICAgICAgICAgICBjb25zdCBub2RlID0gbmV3IGNjLk5vZGUoJ1Nwcml0ZScpO1xuICAgICAgICAgICAgY29uc3Qgc3AgPSBub2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuXG4gICAgICAgICAgICBzcC5zcHJpdGVGcmFtZSA9IHRoaXMucGFydGljbGU7XG4gICAgICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMubm9kZTtcblxuICAgICAgICAgICAgY29uc3QgYSA9IDM1OSAqIE1hdGgucmFuZG9tKCksXG4gICAgICAgICAgICAgICAgaSA9IDMwICogTWF0aC5yYW5kb20oKSArIHdpZHRoIC8gMixcbiAgICAgICAgICAgICAgICBsID0gY2MudjIoTWF0aC5zaW4oYSAqIE1hdGguUEkgLyAxODApICogaSwgTWF0aC5jb3MoYSAqIE1hdGguUEkgLyAxODApICogaSk7XG4gICAgICAgICAgICBub2RlLnNjYWxlID0gLjUgKiBNYXRoLnJhbmRvbSgpICsgd2lkdGggLyAxMDA7XG4gICAgICAgICAgICBjb25zdCBwID0gLjUgKiBNYXRoLnJhbmRvbSgpO1xuXG4gICAgICAgICAgICBub2RlLnBvc2l0aW9uID0gcG9zO1xuICAgICAgICAgICAgbm9kZS5ydW5BY3Rpb24oXG4gICAgICAgICAgICAgICAgY2Muc2VxdWVuY2UoY2Muc3Bhd24oY2MubW92ZUJ5KHAsIGwpLFxuICAgICAgICAgICAgICAgICAgICBjYy5zY2FsZVRvKHAgKyAuNSwgLjMpLFxuICAgICAgICAgICAgICAgICAgICBjYy5yb3RhdGVCeShwICsgLjUsIFJhbmRvbUludGVnZXIoLTM2MCwgMzYwKSkpLFxuICAgICAgICAgICAgICAgICAgICBjYy5mYWRlT3V0KC4xKSxcbiAgICAgICAgICAgICAgICAgICAgY2MuY2FsbEZ1bmMoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfSwgdGhpcykpXG4gICAgICAgICAgICApXG4gICAgICAgIH1cblxuICAgICAgICAvLyDmsLTnj6BcbiAgICAgICAgZm9yIChsZXQgZiA9IDA7IGYgPCAyMDsgZisrKSB7XG4gICAgICAgICAgICBjb25zdCBub2RlID0gbmV3IGNjLk5vZGUoJ1Nwcml0ZScpO1xuICAgICAgICAgICAgY29uc3Qgc3AgPSBub2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuXG4gICAgICAgICAgICBzcC5zcHJpdGVGcmFtZSA9IHRoaXMuY2lyY2xlO1xuICAgICAgICAgICAgbm9kZS5wYXJlbnQgPSB0aGlzLm5vZGU7XG5cbiAgICAgICAgICAgIGxldCBhID0gMzU5ICogTWF0aC5yYW5kb20oKSwgaSA9IDMwICogTWF0aC5yYW5kb20oKSArIHdpZHRoIC8gMixcbiAgICAgICAgICAgICAgICBsID0gY2MudjIoTWF0aC5zaW4oYSAqIE1hdGguUEkgLyAxODApICogaSwgTWF0aC5jb3MoYSAqIE1hdGguUEkgLyAxODApICogaSk7XG4gICAgICAgICAgICBub2RlLnNjYWxlID0gLjUgKiBNYXRoLnJhbmRvbSgpICsgd2lkdGggLyAxMDA7XG4gICAgICAgICAgICBsZXQgcCA9IC41ICogTWF0aC5yYW5kb20oKTtcbiAgICAgICAgICAgIG5vZGUucG9zaXRpb24gPSBwb3M7XG4gICAgICAgICAgICBub2RlLnJ1bkFjdGlvbihjYy5zZXF1ZW5jZShjYy5zcGF3bihjYy5tb3ZlQnkocCwgbCksIGNjLnNjYWxlVG8ocCArIC41LCAuMykpLCBjYy5mYWRlT3V0KC4xKSwgY2MuY2FsbEZ1bmMoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIG5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICB9LCB0aGlzKSkpXG4gICAgICAgIH1cblxuICAgICAgICAvLyDmnpzmsYFcbiAgICAgICAgY29uc3Qgbm9kZSA9IG5ldyBjYy5Ob2RlKCdTcHJpdGUnKTtcbiAgICAgICAgY29uc3Qgc3AgPSBub2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuXG4gICAgICAgIHNwLnNwcml0ZUZyYW1lID0gdGhpcy5zbGFzaDtcbiAgICAgICAgbm9kZS5wYXJlbnQgPSB0aGlzLm5vZGU7XG5cbiAgICAgICAgbm9kZS5wb3NpdGlvbiA9IHBvcztcbiAgICAgICAgbm9kZS5zY2FsZSA9IDA7XG4gICAgICAgIG5vZGUuYW5nbGUgPSBSYW5kb21JbnRlZ2VyKDAsIDM2MCk7XG4gICAgICAgIG5vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGNjLnNwYXduKGNjLnNjYWxlVG8oLjIsIHdpZHRoIC8gMTUwKSwgY2MuZmFkZU91dCgxKSksIGNjLmNhbGxGdW5jKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIG5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH0pKSlcbiAgICB9LFxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Fruit.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '365b4UAiQRBA7QXa2IuFMmj', 'Fruit');
// scripts/Fruit.js

"use strict";

// const Game = require("Game");
cc.Class({
  "extends": cc.Component,
  properties: {
    id: 0 // game: Game

  },
  init: function init(data) {
    this.id = data.id;
    var sp = this.node.getComponent(cc.Sprite);
    sp.spriteFrame = data.iconSF; // todo 控制一下每种水果的尺寸
  },
  start: function start() {},
  onBeginContact: function onBeginContact(contact, self, other) {
    // 貌似检测有点消耗性能
    if (self.node && other.node) {
      var s = self.node.getComponent('Fruit');
      var o = other.node.getComponent('Fruit');

      if (s && o && s.id === o.id) {
        self.node.emit('sameContact', {
          self: self,
          other: other
        });
      }
    }
  },
  update: function update() {
    // console.log(111)
    if (!this.node.getComponent(cc.RigidBody).awake && this.node.y >= cc.find("Canvas/xuxian").y) {
      cc.find("Canvas").getComponent("Game").gameover();
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRnJ1aXQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJpZCIsImluaXQiLCJkYXRhIiwic3AiLCJub2RlIiwiZ2V0Q29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJpY29uU0YiLCJzdGFydCIsIm9uQmVnaW5Db250YWN0IiwiY29udGFjdCIsInNlbGYiLCJvdGhlciIsInMiLCJvIiwiZW1pdCIsInVwZGF0ZSIsIlJpZ2lkQm9keSIsImF3YWtlIiwieSIsImZpbmQiLCJnYW1lb3ZlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUNMLFdBQVNELEVBQUUsQ0FBQ0UsU0FEUDtFQUdMQyxVQUFVLEVBQUU7SUFDUkMsRUFBRSxFQUFFLENBREksQ0FFUjs7RUFGUSxDQUhQO0VBT0xDLElBUEssZ0JBT0FDLElBUEEsRUFPTTtJQUNQLEtBQUtGLEVBQUwsR0FBVUUsSUFBSSxDQUFDRixFQUFmO0lBQ0EsSUFBTUcsRUFBRSxHQUFHLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QlQsRUFBRSxDQUFDVSxNQUExQixDQUFYO0lBQ0FILEVBQUUsQ0FBQ0ksV0FBSCxHQUFpQkwsSUFBSSxDQUFDTSxNQUF0QixDQUhPLENBSVA7RUFDSCxDQVpJO0VBYUxDLEtBYkssbUJBYUcsQ0FFUCxDQWZJO0VBZ0JMQyxjQWhCSywwQkFnQlVDLE9BaEJWLEVBZ0JtQkMsSUFoQm5CLEVBZ0J5QkMsS0FoQnpCLEVBZ0JnQztJQUNqQztJQUNBLElBQUlELElBQUksQ0FBQ1IsSUFBTCxJQUFhUyxLQUFLLENBQUNULElBQXZCLEVBQTZCO01BQ3pCLElBQU1VLENBQUMsR0FBR0YsSUFBSSxDQUFDUixJQUFMLENBQVVDLFlBQVYsQ0FBdUIsT0FBdkIsQ0FBVjtNQUNBLElBQU1VLENBQUMsR0FBR0YsS0FBSyxDQUFDVCxJQUFOLENBQVdDLFlBQVgsQ0FBd0IsT0FBeEIsQ0FBVjs7TUFDQSxJQUFJUyxDQUFDLElBQUlDLENBQUwsSUFBVUQsQ0FBQyxDQUFDZCxFQUFGLEtBQVNlLENBQUMsQ0FBQ2YsRUFBekIsRUFBNkI7UUFDekJZLElBQUksQ0FBQ1IsSUFBTCxDQUFVWSxJQUFWLENBQWUsYUFBZixFQUE4QjtVQUFFSixJQUFJLEVBQUpBLElBQUY7VUFBUUMsS0FBSyxFQUFMQTtRQUFSLENBQTlCO01BQ0g7SUFDSjtFQUNKLENBekJJO0VBMkJMSSxNQTNCSyxvQkEyQkk7SUFDTDtJQUNBLElBQUksQ0FBQyxLQUFLYixJQUFMLENBQVVDLFlBQVYsQ0FBdUJULEVBQUUsQ0FBQ3NCLFNBQTFCLEVBQXFDQyxLQUF0QyxJQUErQyxLQUFLZixJQUFMLENBQVVnQixDQUFWLElBQWV4QixFQUFFLENBQUN5QixJQUFILENBQVEsZUFBUixFQUF5QkQsQ0FBM0YsRUFBOEY7TUFDMUZ4QixFQUFFLENBQUN5QixJQUFILENBQVEsUUFBUixFQUFrQmhCLFlBQWxCLENBQStCLE1BQS9CLEVBQXVDaUIsUUFBdkM7SUFDSDtFQUNKO0FBaENJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxuLy8gY29uc3QgR2FtZSA9IHJlcXVpcmUoXCJHYW1lXCIpO1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgaWQ6IDAsXG4gICAgICAgIC8vIGdhbWU6IEdhbWVcbiAgICB9LFxuICAgIGluaXQoZGF0YSkge1xuICAgICAgICB0aGlzLmlkID0gZGF0YS5pZFxuICAgICAgICBjb25zdCBzcCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgc3Auc3ByaXRlRnJhbWUgPSBkYXRhLmljb25TRjtcbiAgICAgICAgLy8gdG9kbyDmjqfliLbkuIDkuIvmr4/np43msLTmnpznmoTlsLrlr7hcbiAgICB9LFxuICAgIHN0YXJ0KCkge1xuXG4gICAgfSxcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikge1xuICAgICAgICAvLyDosozkvLzmo4DmtYvmnInngrnmtojogJfmgKfog71cbiAgICAgICAgaWYgKHNlbGYubm9kZSAmJiBvdGhlci5ub2RlKSB7XG4gICAgICAgICAgICBjb25zdCBzID0gc2VsZi5ub2RlLmdldENvbXBvbmVudCgnRnJ1aXQnKTtcbiAgICAgICAgICAgIGNvbnN0IG8gPSBvdGhlci5ub2RlLmdldENvbXBvbmVudCgnRnJ1aXQnKTtcbiAgICAgICAgICAgIGlmIChzICYmIG8gJiYgcy5pZCA9PT0gby5pZCkge1xuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5lbWl0KCdzYW1lQ29udGFjdCcsIHsgc2VsZiwgb3RoZXIgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgdXBkYXRlKCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZygxMTEpXG4gICAgICAgIGlmICghdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5SaWdpZEJvZHkpLmF3YWtlICYmIHRoaXMubm9kZS55ID49IGNjLmZpbmQoXCJDYW52YXMveHV4aWFuXCIpLnkpIHtcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXNcIikuZ2V0Q29tcG9uZW50KFwiR2FtZVwiKS5nYW1lb3ZlcigpO1xuICAgICAgICB9XG4gICAgfVxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Over.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8208cLeoTtKxIVX6aTTYYxC', 'Over');
// scripts/Over.js

"use strict";

var Game = require("Game");

cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    best: cc.Label,
    score: cc.Label,
    game: Game
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad() {
  // },
  start: function start() {
    this.showScore();
  },
  onBtnClick: function onBtnClick() {
    cc.director.loadScene("game");
  },
  showScore: function showScore() {
    this.score.string = "Score:" + this.game.scoreNum;
    var bestScore = Number(cc.sys.localStorage.getItem('hcdxg'));

    if (!bestScore) {
      this.best.string = "Best:" + this.game.scoreNum;
      cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
    } else {
      if (bestScore < this.game.scoreNum) {
        this.best.string = "Best:" + this.game.scoreNum;
        cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
      } else {
        this.best.string = "Best:" + bestScore;
      }
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcT3Zlci5qcyJdLCJuYW1lcyI6WyJHYW1lIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYmVzdCIsIkxhYmVsIiwic2NvcmUiLCJnYW1lIiwic3RhcnQiLCJzaG93U2NvcmUiLCJvbkJ0bkNsaWNrIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJzdHJpbmciLCJzY29yZU51bSIsImJlc3RTY29yZSIsIk51bWJlciIsInN5cyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzZXRJdGVtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQU1BLElBQUksR0FBR0MsT0FBTyxDQUFDLE1BQUQsQ0FBcEI7O0FBRUFDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ0wsV0FBU0QsRUFBRSxDQUFDRSxTQURQO0VBR0xDLFVBQVUsRUFBRTtJQUNSO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUVBQyxJQUFJLEVBQUVKLEVBQUUsQ0FBQ0ssS0FqQkQ7SUFrQlJDLEtBQUssRUFBRU4sRUFBRSxDQUFDSyxLQWxCRjtJQW9CUkUsSUFBSSxFQUFFVDtFQXBCRSxDQUhQO0VBMEJMO0VBRUE7RUFFQTtFQUVBVSxLQWhDSyxtQkFnQ0c7SUFFSixLQUFLQyxTQUFMO0VBQ0gsQ0FuQ0k7RUFxQ0xDLFVBckNLLHdCQXFDUTtJQUNUVixFQUFFLENBQUNXLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtFQUNILENBdkNJO0VBeUNMSCxTQXpDSyx1QkF5Q087SUFDUixLQUFLSCxLQUFMLENBQVdPLE1BQVgsY0FBNkIsS0FBS04sSUFBTCxDQUFVTyxRQUF2QztJQUNBLElBQUlDLFNBQVMsR0FBR0MsTUFBTSxDQUFDaEIsRUFBRSxDQUFDaUIsR0FBSCxDQUFPQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QixPQUE1QixDQUFELENBQXRCOztJQUNBLElBQUksQ0FBQ0osU0FBTCxFQUFnQjtNQUNaLEtBQUtYLElBQUwsQ0FBVVMsTUFBVixhQUEyQixLQUFLTixJQUFMLENBQVVPLFFBQXJDO01BQ0FkLEVBQUUsQ0FBQ2lCLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkUsT0FBcEIsQ0FBNEIsT0FBNUIsRUFBcUMsS0FBS2IsSUFBTCxDQUFVTyxRQUEvQztJQUNILENBSEQsTUFHTztNQUNILElBQUlDLFNBQVMsR0FBRyxLQUFLUixJQUFMLENBQVVPLFFBQTFCLEVBQW9DO1FBQ2hDLEtBQUtWLElBQUwsQ0FBVVMsTUFBVixhQUEyQixLQUFLTixJQUFMLENBQVVPLFFBQXJDO1FBQ0FkLEVBQUUsQ0FBQ2lCLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkUsT0FBcEIsQ0FBNEIsT0FBNUIsRUFBcUMsS0FBS2IsSUFBTCxDQUFVTyxRQUEvQztNQUNILENBSEQsTUFHTztRQUNILEtBQUtWLElBQUwsQ0FBVVMsTUFBVixhQUEyQkUsU0FBM0I7TUFDSDtJQUNKO0VBQ0osQ0F2REksQ0F5REw7O0FBekRLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IEdhbWUgPSByZXF1aXJlKFwiR2FtZVwiKTtcblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgICAvLyBBVFRSSUJVVEVTOlxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIGJhcjoge1xuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gdGhpcy5fYmFyO1xuICAgICAgICAvLyAgICAgfSxcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9iYXIgPSB2YWx1ZTtcbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gfSxcblxuICAgICAgICBiZXN0OiBjYy5MYWJlbCxcbiAgICAgICAgc2NvcmU6IGNjLkxhYmVsLFxuXG4gICAgICAgIGdhbWU6IEdhbWVcbiAgICB9LFxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICAvLyBvbkxvYWQoKSB7XG5cbiAgICAvLyB9LFxuXG4gICAgc3RhcnQoKSB7XG5cbiAgICAgICAgdGhpcy5zaG93U2NvcmUoKTtcbiAgICB9LFxuXG4gICAgb25CdG5DbGljaygpIHtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiZ2FtZVwiKTtcbiAgICB9LFxuXG4gICAgc2hvd1Njb3JlKCkge1xuICAgICAgICB0aGlzLnNjb3JlLnN0cmluZyA9IGBTY29yZToke3RoaXMuZ2FtZS5zY29yZU51bX1gO1xuICAgICAgICBsZXQgYmVzdFNjb3JlID0gTnVtYmVyKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaGNkeGcnKSk7XG4gICAgICAgIGlmICghYmVzdFNjb3JlKSB7XG4gICAgICAgICAgICB0aGlzLmJlc3Quc3RyaW5nID0gYEJlc3Q6JHt0aGlzLmdhbWUuc2NvcmVOdW19YDtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaGNkeGcnLCB0aGlzLmdhbWUuc2NvcmVOdW0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGJlc3RTY29yZSA8IHRoaXMuZ2FtZS5zY29yZU51bSkge1xuICAgICAgICAgICAgICAgIHRoaXMuYmVzdC5zdHJpbmcgPSBgQmVzdDoke3RoaXMuZ2FtZS5zY29yZU51bX1gO1xuICAgICAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaGNkeGcnLCB0aGlzLmdhbWUuc2NvcmVOdW0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJlc3Quc3RyaW5nID0gYEJlc3Q6JHtiZXN0U2NvcmV9YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Load.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5ecd9MPU61GUpw7n1FomDlb', 'Load');
// scripts/Load.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  onStartBtnClick: function onStartBtnClick() {
    cc.director.loadScene("game");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTG9hZC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YXJ0Iiwib25TdGFydEJ0bkNsaWNrIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ0wsV0FBU0QsRUFBRSxDQUFDRSxTQURQO0VBR0xDLFVBQVUsRUFBRSxDQUNSO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtFQWZRLENBSFA7RUFxQkw7RUFFQTtFQUVBQyxLQXpCSyxtQkF5QkcsQ0FFUCxDQTNCSTtFQTZCTEMsZUE3QkssNkJBNkJhO0lBQ2RMLEVBQUUsQ0FBQ00sUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0VBQ0gsQ0EvQkksQ0FpQ0w7O0FBakNLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsICAgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgICBzZXJpYWxpemFibGU6IHRydWUsICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyBiYXI6IHtcbiAgICAgICAgLy8gICAgIGdldCAoKSB7XG4gICAgICAgIC8vICAgICAgICAgcmV0dXJuIHRoaXMuX2JhcjtcbiAgICAgICAgLy8gICAgIH0sXG4gICAgICAgIC8vICAgICBzZXQgKHZhbHVlKSB7XG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fYmFyID0gdmFsdWU7XG4gICAgICAgIC8vICAgICB9XG4gICAgICAgIC8vIH0sXG4gICAgfSxcblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgLy8gb25Mb2FkICgpIHt9LFxuXG4gICAgc3RhcnQoKSB7XG5cbiAgICB9LFxuXG4gICAgb25TdGFydEJ0bkNsaWNrKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJnYW1lXCIpO1xuICAgIH1cblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8e80dMWyH5LD7Oj100K42f8', 'Game');
// scripts/Game.js

"use strict";

var Fruit = cc.Class({
  name: 'FruitItem',
  properties: {
    id: 0,
    iconSF: cc.SpriteFrame
  }
});
var JuiceItem = cc.Class({
  name: 'JuiceItem',
  properties: {
    particle: cc.SpriteFrame,
    circle: cc.SpriteFrame,
    slash: cc.SpriteFrame
  }
}); // module.exports = this;

cc.Class({
  "extends": cc.Component,
  properties: {
    fruits: {
      "default": [],
      type: Fruit
    },
    juices: {
      "default": [],
      type: JuiceItem
    },
    // 动态生成 找到批量处理预置元素的方案
    fruitPrefab: {
      "default": null,
      type: cc.Prefab
    },
    juicePrefab: {
      "default": null,
      type: cc.Prefab
    },
    // todo 可以实现一个audioManager
    boomAudio: {
      "default": null,
      type: cc.AudioClip
    },
    knockAudio: {
      "default": null,
      type: cc.AudioClip
    },
    waterAudio: {
      "default": null,
      type: cc.AudioClip
    },
    score: {
      "default": null,
      type: cc.Label
    },
    mask: {
      "default": null,
      type: cc.Node
    }
  },
  onLoad: function onLoad() {
    this.initPhysics();
    this.isCreating = false;
    this.fruitCount = 0;
    this.scoreNum = 0;
    this.fruitsList = []; // 监听点击事件 todo 是否能够注册全局事件

    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
    this.initOneFruit();
  },
  // 开启物理引擎和碰撞检测
  initPhysics: function initPhysics() {
    // 物理引擎
    var instance = cc.director.getPhysicsManager();
    instance.enabled = true; // instance.debugDrawFlags = 4

    instance.gravity = cc.v2(0, -960); // 碰撞检测

    var collisionManager = cc.director.getCollisionManager();
    collisionManager.enabled = true; // 设置四周的碰撞区域

    var width = this.node.width;
    var height = this.node.height;
    var node = new cc.Node();
    var body = node.addComponent(cc.RigidBody);
    body.type = cc.RigidBodyType.Static;

    var _addBound = function _addBound(node, x, y, width, height) {
      var collider = node.addComponent(cc.PhysicsBoxCollider);
      collider.offset.x = x;
      collider.offset.y = y;
      collider.size.width = width;
      collider.size.height = height;
    };

    _addBound(node, 0, -height / 2, width, 1);

    _addBound(node, 0, height / 2, width, 1);

    _addBound(node, -width / 2, 0, 1, height);

    _addBound(node, width / 2, 0, 1, height);

    node.parent = this.node;
  },
  initOneFruit: function initOneFruit(id) {
    if (id === void 0) {
      id = 1;
    }

    this.fruitCount++;
    this.currentFruit = this.createFruitOnPos(0, 400, id);
  },
  // 监听屏幕点击
  onTouchStart: function onTouchStart(e) {
    var _this = this;

    if (this.isCreating) return;
    this.isCreating = true; // console.log("55555555555555555")

    var _this$node = this.node,
        width = _this$node.width,
        height = _this$node.height;
    var fruit = this.currentFruit;
    var pos = e.getLocation();
    var x = pos.x,
        y = pos.y;
    x = x - width / 2;
    y = y - height / 2;
    var action = cc.sequence(cc.moveBy(0.3, cc.v2(x, 0)).easing(cc.easeCubicActionIn()), cc.callFunc(function () {
      // 开启物理效果
      _this.startFruitPhysics(fruit); // 1s后重新生成一个


      _this.scheduleOnce(function () {
        var nextId = _this.getNextFruitId();

        _this.initOneFruit(nextId);

        _this.isCreating = false; // console.log("9999999999999999999")
      }, 1);
    }));
    fruit.runAction(action); // console.log(this.currentFruit.getComponent(cc.Sprite).spriteFrame.name)

    console.log(this.currentFruit.name);
  },
  // 获取下一个水果的id
  getNextFruitId: function getNextFruitId() {
    if (this.fruitCount < 3) {
      return 1;
    } else if (this.fruitCount === 3) {
      return 2;
    } else {
      // 随机返回前5个
      return Math.floor(Math.random() * 5) + 1;
    }
  },
  // 创建一个水果
  createOneFruit: function createOneFruit(num) {
    var fruit = cc.instantiate(this.fruitPrefab);
    var config = this.fruits[num - 1];
    fruit.getComponent('Fruit').init({
      id: config.id,
      iconSF: config.iconSF
    });
    fruit.getComponent(cc.RigidBody).type = cc.RigidBodyType.Static;
    fruit.getComponent(cc.PhysicsCircleCollider).radius = 0;
    this.node.addChild(fruit);
    fruit.scale = 0.6; // 有Fruit组件传入

    fruit.on('sameContact', this.onSameFruitContact.bind(this));
    return fruit;
  },
  startFruitPhysics: function startFruitPhysics(fruit) {
    fruit.getComponent(cc.RigidBody).type = cc.RigidBodyType.Dynamic;
    var physicsCircleCollider = fruit.getComponent(cc.PhysicsCircleCollider);
    physicsCircleCollider.radius = fruit.height / 2;
    physicsCircleCollider.apply();
  },
  // 在指定位置生成水果
  createFruitOnPos: function createFruitOnPos(x, y, type) {
    if (type === void 0) {
      type = 1;
    }

    var fruit = this.createOneFruit(type);
    fruit.setPosition(cc.v2(x, y));
    return fruit;
  },
  // 两个水果碰撞
  onSameFruitContact: function onSameFruitContact(_ref) {
    var self = _ref.self,
        other = _ref.other;
    other.node.off('sameContact'); // 两个node都会触发，todo 看看有没有其他方法只展示一次的

    var id = other.getComponent('Fruit').id; // todo 可以使用对象池回收

    self.node.removeFromParent(false);
    other.node.removeFromParent(false);
    var _other$node = other.node,
        x = _other$node.x,
        y = _other$node.y;
    this.createFruitJuice(id, cc.v2({
      x: x,
      y: y
    }), other.node.width);
    var nextId = id + 1;

    if (nextId <= 11) {
      var newFruit = this.createFruitOnPos(x, y, nextId); // console.log(newFruit);

      this.scoreNum += nextId * 10;
      this.score.string = "Score:" + this.scoreNum; // console.log(newFruit.getComponent("Fruit").id);

      this.startFruitPhysics(newFruit); // 展示动画 todo 动画效果需要调整

      newFruit.scale = 0;
      cc.tween(newFruit).to(.5, {
        scale: 0.6
      }, {
        easing: "backOut"
      }).start();
    } else {
      // todo 合成两个西瓜
      console.log(' todo 合成两个西瓜');
    }
  },
  // 合并时的动画效果
  createFruitJuice: function createFruitJuice(id, pos, n) {
    // 播放合并的声音
    cc.audioEngine.play(this.boomAudio, false, 1);
    cc.audioEngine.play(this.waterAudio, false, 1); // 展示动画

    var juice = cc.instantiate(this.juicePrefab);
    this.node.addChild(juice);
    var config = this.juices[id - 1];
    var instance = juice.getComponent('Juice');
    instance.init(config);
    instance.showJuice(pos, n);
  },
  gameover: function gameover() {
    this.mask.active = true;
    this.mask.zIndex = 1;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZS5qcyJdLCJuYW1lcyI6WyJGcnVpdCIsImNjIiwiQ2xhc3MiLCJuYW1lIiwicHJvcGVydGllcyIsImlkIiwiaWNvblNGIiwiU3ByaXRlRnJhbWUiLCJKdWljZUl0ZW0iLCJwYXJ0aWNsZSIsImNpcmNsZSIsInNsYXNoIiwiQ29tcG9uZW50IiwiZnJ1aXRzIiwidHlwZSIsImp1aWNlcyIsImZydWl0UHJlZmFiIiwiUHJlZmFiIiwianVpY2VQcmVmYWIiLCJib29tQXVkaW8iLCJBdWRpb0NsaXAiLCJrbm9ja0F1ZGlvIiwid2F0ZXJBdWRpbyIsInNjb3JlIiwiTGFiZWwiLCJtYXNrIiwiTm9kZSIsIm9uTG9hZCIsImluaXRQaHlzaWNzIiwiaXNDcmVhdGluZyIsImZydWl0Q291bnQiLCJzY29yZU51bSIsImZydWl0c0xpc3QiLCJub2RlIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsIm9uVG91Y2hTdGFydCIsImluaXRPbmVGcnVpdCIsImluc3RhbmNlIiwiZGlyZWN0b3IiLCJnZXRQaHlzaWNzTWFuYWdlciIsImVuYWJsZWQiLCJncmF2aXR5IiwidjIiLCJjb2xsaXNpb25NYW5hZ2VyIiwiZ2V0Q29sbGlzaW9uTWFuYWdlciIsIndpZHRoIiwiaGVpZ2h0IiwiYm9keSIsImFkZENvbXBvbmVudCIsIlJpZ2lkQm9keSIsIlJpZ2lkQm9keVR5cGUiLCJTdGF0aWMiLCJfYWRkQm91bmQiLCJ4IiwieSIsImNvbGxpZGVyIiwiUGh5c2ljc0JveENvbGxpZGVyIiwib2Zmc2V0Iiwic2l6ZSIsInBhcmVudCIsImN1cnJlbnRGcnVpdCIsImNyZWF0ZUZydWl0T25Qb3MiLCJlIiwiZnJ1aXQiLCJwb3MiLCJnZXRMb2NhdGlvbiIsImFjdGlvbiIsInNlcXVlbmNlIiwibW92ZUJ5IiwiZWFzaW5nIiwiZWFzZUN1YmljQWN0aW9uSW4iLCJjYWxsRnVuYyIsInN0YXJ0RnJ1aXRQaHlzaWNzIiwic2NoZWR1bGVPbmNlIiwibmV4dElkIiwiZ2V0TmV4dEZydWl0SWQiLCJydW5BY3Rpb24iLCJjb25zb2xlIiwibG9nIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwiY3JlYXRlT25lRnJ1aXQiLCJudW0iLCJpbnN0YW50aWF0ZSIsImNvbmZpZyIsImdldENvbXBvbmVudCIsImluaXQiLCJQaHlzaWNzQ2lyY2xlQ29sbGlkZXIiLCJyYWRpdXMiLCJhZGRDaGlsZCIsInNjYWxlIiwib25TYW1lRnJ1aXRDb250YWN0IiwiYmluZCIsIkR5bmFtaWMiLCJwaHlzaWNzQ2lyY2xlQ29sbGlkZXIiLCJhcHBseSIsInNldFBvc2l0aW9uIiwic2VsZiIsIm90aGVyIiwib2ZmIiwicmVtb3ZlRnJvbVBhcmVudCIsImNyZWF0ZUZydWl0SnVpY2UiLCJuZXdGcnVpdCIsInN0cmluZyIsInR3ZWVuIiwidG8iLCJzdGFydCIsIm4iLCJhdWRpb0VuZ2luZSIsInBsYXkiLCJqdWljZSIsInNob3dKdWljZSIsImdhbWVvdmVyIiwiYWN0aXZlIiwiekluZGV4Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQU1BLEtBQUssR0FBR0MsRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDbkJDLElBQUksRUFBRSxXQURhO0VBRW5CQyxVQUFVLEVBQUU7SUFDUkMsRUFBRSxFQUFFLENBREk7SUFFUkMsTUFBTSxFQUFFTCxFQUFFLENBQUNNO0VBRkg7QUFGTyxDQUFULENBQWQ7QUFRQSxJQUFNQyxTQUFTLEdBQUdQLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ3ZCQyxJQUFJLEVBQUUsV0FEaUI7RUFFdkJDLFVBQVUsRUFBRTtJQUNSSyxRQUFRLEVBQUVSLEVBQUUsQ0FBQ00sV0FETDtJQUVSRyxNQUFNLEVBQUVULEVBQUUsQ0FBQ00sV0FGSDtJQUdSSSxLQUFLLEVBQUVWLEVBQUUsQ0FBQ007RUFIRjtBQUZXLENBQVQsQ0FBbEIsRUFTQTs7QUFHQU4sRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDTCxXQUFTRCxFQUFFLENBQUNXLFNBRFA7RUFHTFIsVUFBVSxFQUFFO0lBQ1JTLE1BQU0sRUFBRTtNQUNKLFdBQVMsRUFETDtNQUVKQyxJQUFJLEVBQUVkO0lBRkYsQ0FEQTtJQU1SZSxNQUFNLEVBQUU7TUFDSixXQUFTLEVBREw7TUFFSkQsSUFBSSxFQUFFTjtJQUZGLENBTkE7SUFXUjtJQUNBUSxXQUFXLEVBQUU7TUFDVCxXQUFTLElBREE7TUFFVEYsSUFBSSxFQUFFYixFQUFFLENBQUNnQjtJQUZBLENBWkw7SUFpQlJDLFdBQVcsRUFBRTtNQUNULFdBQVMsSUFEQTtNQUVUSixJQUFJLEVBQUViLEVBQUUsQ0FBQ2dCO0lBRkEsQ0FqQkw7SUFzQlI7SUFDQUUsU0FBUyxFQUFFO01BQ1AsV0FBUyxJQURGO01BRVBMLElBQUksRUFBRWIsRUFBRSxDQUFDbUI7SUFGRixDQXZCSDtJQTJCUkMsVUFBVSxFQUFFO01BQ1IsV0FBUyxJQUREO01BRVJQLElBQUksRUFBRWIsRUFBRSxDQUFDbUI7SUFGRCxDQTNCSjtJQStCUkUsVUFBVSxFQUFFO01BQ1IsV0FBUyxJQUREO01BRVJSLElBQUksRUFBRWIsRUFBRSxDQUFDbUI7SUFGRCxDQS9CSjtJQW9DUkcsS0FBSyxFQUFFO01BQ0gsV0FBUyxJQUROO01BRUhULElBQUksRUFBRWIsRUFBRSxDQUFDdUI7SUFGTixDQXBDQztJQXlDUkMsSUFBSSxFQUFFO01BQ0YsV0FBUyxJQURQO01BRUZYLElBQUksRUFBRWIsRUFBRSxDQUFDeUI7SUFGUDtFQXpDRSxDQUhQO0VBa0RMQyxNQWxESyxvQkFrREk7SUFDTCxLQUFLQyxXQUFMO0lBQ0EsS0FBS0MsVUFBTCxHQUFrQixLQUFsQjtJQUNBLEtBQUtDLFVBQUwsR0FBa0IsQ0FBbEI7SUFDQSxLQUFLQyxRQUFMLEdBQWdCLENBQWhCO0lBQ0EsS0FBS0MsVUFBTCxHQUFrQixFQUFsQixDQUxLLENBTUw7O0lBQ0EsS0FBS0MsSUFBTCxDQUFVQyxFQUFWLENBQWFqQyxFQUFFLENBQUN5QixJQUFILENBQVFTLFNBQVIsQ0FBa0JDLFdBQS9CLEVBQTRDLEtBQUtDLFlBQWpELEVBQStELElBQS9EO0lBRUEsS0FBS0MsWUFBTDtFQUNILENBNURJO0VBOERMO0VBQ0FWLFdBL0RLLHlCQStEUztJQUNWO0lBQ0EsSUFBTVcsUUFBUSxHQUFHdEMsRUFBRSxDQUFDdUMsUUFBSCxDQUFZQyxpQkFBWixFQUFqQjtJQUNBRixRQUFRLENBQUNHLE9BQVQsR0FBbUIsSUFBbkIsQ0FIVSxDQUlWOztJQUNBSCxRQUFRLENBQUNJLE9BQVQsR0FBbUIxQyxFQUFFLENBQUMyQyxFQUFILENBQU0sQ0FBTixFQUFTLENBQUMsR0FBVixDQUFuQixDQUxVLENBT1Y7O0lBQ0EsSUFBTUMsZ0JBQWdCLEdBQUc1QyxFQUFFLENBQUN1QyxRQUFILENBQVlNLG1CQUFaLEVBQXpCO0lBQ0FELGdCQUFnQixDQUFDSCxPQUFqQixHQUEyQixJQUEzQixDQVRVLENBV1Y7O0lBQ0EsSUFBSUssS0FBSyxHQUFHLEtBQUtkLElBQUwsQ0FBVWMsS0FBdEI7SUFDQSxJQUFJQyxNQUFNLEdBQUcsS0FBS2YsSUFBTCxDQUFVZSxNQUF2QjtJQUVBLElBQUlmLElBQUksR0FBRyxJQUFJaEMsRUFBRSxDQUFDeUIsSUFBUCxFQUFYO0lBRUEsSUFBSXVCLElBQUksR0FBR2hCLElBQUksQ0FBQ2lCLFlBQUwsQ0FBa0JqRCxFQUFFLENBQUNrRCxTQUFyQixDQUFYO0lBQ0FGLElBQUksQ0FBQ25DLElBQUwsR0FBWWIsRUFBRSxDQUFDbUQsYUFBSCxDQUFpQkMsTUFBN0I7O0lBRUEsSUFBTUMsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ3JCLElBQUQsRUFBT3NCLENBQVAsRUFBVUMsQ0FBVixFQUFhVCxLQUFiLEVBQW9CQyxNQUFwQixFQUErQjtNQUM3QyxJQUFJUyxRQUFRLEdBQUd4QixJQUFJLENBQUNpQixZQUFMLENBQWtCakQsRUFBRSxDQUFDeUQsa0JBQXJCLENBQWY7TUFDQUQsUUFBUSxDQUFDRSxNQUFULENBQWdCSixDQUFoQixHQUFvQkEsQ0FBcEI7TUFDQUUsUUFBUSxDQUFDRSxNQUFULENBQWdCSCxDQUFoQixHQUFvQkEsQ0FBcEI7TUFDQUMsUUFBUSxDQUFDRyxJQUFULENBQWNiLEtBQWQsR0FBc0JBLEtBQXRCO01BQ0FVLFFBQVEsQ0FBQ0csSUFBVCxDQUFjWixNQUFkLEdBQXVCQSxNQUF2QjtJQUNILENBTkQ7O0lBUUFNLFNBQVMsQ0FBQ3JCLElBQUQsRUFBTyxDQUFQLEVBQVUsQ0FBQ2UsTUFBRCxHQUFVLENBQXBCLEVBQXVCRCxLQUF2QixFQUE4QixDQUE5QixDQUFUOztJQUNBTyxTQUFTLENBQUNyQixJQUFELEVBQU8sQ0FBUCxFQUFVZSxNQUFNLEdBQUcsQ0FBbkIsRUFBc0JELEtBQXRCLEVBQTZCLENBQTdCLENBQVQ7O0lBQ0FPLFNBQVMsQ0FBQ3JCLElBQUQsRUFBTyxDQUFDYyxLQUFELEdBQVMsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBdEIsRUFBeUJDLE1BQXpCLENBQVQ7O0lBQ0FNLFNBQVMsQ0FBQ3JCLElBQUQsRUFBT2MsS0FBSyxHQUFHLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUIsQ0FBckIsRUFBd0JDLE1BQXhCLENBQVQ7O0lBRUFmLElBQUksQ0FBQzRCLE1BQUwsR0FBYyxLQUFLNUIsSUFBbkI7RUFDSCxDQWpHSTtFQW1HTEssWUFuR0ssd0JBbUdRakMsRUFuR1IsRUFtR2dCO0lBQUEsSUFBUkEsRUFBUTtNQUFSQSxFQUFRLEdBQUgsQ0FBRztJQUFBOztJQUNqQixLQUFLeUIsVUFBTDtJQUNBLEtBQUtnQyxZQUFMLEdBQW9CLEtBQUtDLGdCQUFMLENBQXNCLENBQXRCLEVBQXlCLEdBQXpCLEVBQThCMUQsRUFBOUIsQ0FBcEI7RUFDSCxDQXRHSTtFQXdHTDtFQUNBZ0MsWUF6R0ssd0JBeUdRMkIsQ0F6R1IsRUF5R1c7SUFBQTs7SUFDWixJQUFJLEtBQUtuQyxVQUFULEVBQXFCO0lBQ3JCLEtBQUtBLFVBQUwsR0FBa0IsSUFBbEIsQ0FGWSxDQUdaOztJQUNBLGlCQUEwQixLQUFLSSxJQUEvQjtJQUFBLElBQVFjLEtBQVIsY0FBUUEsS0FBUjtJQUFBLElBQWVDLE1BQWYsY0FBZUEsTUFBZjtJQUVBLElBQU1pQixLQUFLLEdBQUcsS0FBS0gsWUFBbkI7SUFFQSxJQUFNSSxHQUFHLEdBQUdGLENBQUMsQ0FBQ0csV0FBRixFQUFaO0lBQ0EsSUFBTVosQ0FBTixHQUFlVyxHQUFmLENBQU1YLENBQU47SUFBQSxJQUFTQyxDQUFULEdBQWVVLEdBQWYsQ0FBU1YsQ0FBVDtJQUNBRCxDQUFDLEdBQUdBLENBQUMsR0FBR1IsS0FBSyxHQUFHLENBQWhCO0lBQ0FTLENBQUMsR0FBR0EsQ0FBQyxHQUFHUixNQUFNLEdBQUcsQ0FBakI7SUFFQSxJQUFNb0IsTUFBTSxHQUFHbkUsRUFBRSxDQUFDb0UsUUFBSCxDQUFZcEUsRUFBRSxDQUFDcUUsTUFBSCxDQUFVLEdBQVYsRUFBZXJFLEVBQUUsQ0FBQzJDLEVBQUgsQ0FBTVcsQ0FBTixFQUFTLENBQVQsQ0FBZixFQUE0QmdCLE1BQTVCLENBQW1DdEUsRUFBRSxDQUFDdUUsaUJBQUgsRUFBbkMsQ0FBWixFQUF3RXZFLEVBQUUsQ0FBQ3dFLFFBQUgsQ0FBWSxZQUFNO01BQ3JHO01BQ0EsS0FBSSxDQUFDQyxpQkFBTCxDQUF1QlQsS0FBdkIsRUFGcUcsQ0FJckc7OztNQUNBLEtBQUksQ0FBQ1UsWUFBTCxDQUFrQixZQUFNO1FBQ3BCLElBQU1DLE1BQU0sR0FBRyxLQUFJLENBQUNDLGNBQUwsRUFBZjs7UUFDQSxLQUFJLENBQUN2QyxZQUFMLENBQWtCc0MsTUFBbEI7O1FBQ0EsS0FBSSxDQUFDL0MsVUFBTCxHQUFrQixLQUFsQixDQUhvQixDQUlwQjtNQUVILENBTkQsRUFNRyxDQU5IO0lBT0gsQ0Fac0YsQ0FBeEUsQ0FBZjtJQWNBb0MsS0FBSyxDQUFDYSxTQUFOLENBQWdCVixNQUFoQixFQTNCWSxDQTRCWjs7SUFDQVcsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBS2xCLFlBQUwsQ0FBa0IzRCxJQUE5QjtFQUNILENBdklJO0VBd0lMO0VBQ0EwRSxjQXpJSyw0QkF5SVk7SUFDYixJQUFJLEtBQUsvQyxVQUFMLEdBQWtCLENBQXRCLEVBQXlCO01BQ3JCLE9BQU8sQ0FBUDtJQUNILENBRkQsTUFFTyxJQUFJLEtBQUtBLFVBQUwsS0FBb0IsQ0FBeEIsRUFBMkI7TUFDOUIsT0FBTyxDQUFQO0lBQ0gsQ0FGTSxNQUVBO01BQ0g7TUFDQSxPQUFPbUQsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUF2QztJQUNIO0VBQ0osQ0FsSkk7RUFtSkw7RUFDQUMsY0FwSkssMEJBb0pVQyxHQXBKVixFQW9KZTtJQUNoQixJQUFJcEIsS0FBSyxHQUFHaEUsRUFBRSxDQUFDcUYsV0FBSCxDQUFlLEtBQUt0RSxXQUFwQixDQUFaO0lBQ0EsSUFBTXVFLE1BQU0sR0FBRyxLQUFLMUUsTUFBTCxDQUFZd0UsR0FBRyxHQUFHLENBQWxCLENBQWY7SUFFQXBCLEtBQUssQ0FBQ3VCLFlBQU4sQ0FBbUIsT0FBbkIsRUFBNEJDLElBQTVCLENBQWlDO01BQzdCcEYsRUFBRSxFQUFFa0YsTUFBTSxDQUFDbEYsRUFEa0I7TUFFN0JDLE1BQU0sRUFBRWlGLE1BQU0sQ0FBQ2pGO0lBRmMsQ0FBakM7SUFLQTJELEtBQUssQ0FBQ3VCLFlBQU4sQ0FBbUJ2RixFQUFFLENBQUNrRCxTQUF0QixFQUFpQ3JDLElBQWpDLEdBQXdDYixFQUFFLENBQUNtRCxhQUFILENBQWlCQyxNQUF6RDtJQUNBWSxLQUFLLENBQUN1QixZQUFOLENBQW1CdkYsRUFBRSxDQUFDeUYscUJBQXRCLEVBQTZDQyxNQUE3QyxHQUFzRCxDQUF0RDtJQUVBLEtBQUsxRCxJQUFMLENBQVUyRCxRQUFWLENBQW1CM0IsS0FBbkI7SUFDQUEsS0FBSyxDQUFDNEIsS0FBTixHQUFjLEdBQWQsQ0FiZ0IsQ0FlaEI7O0lBQ0E1QixLQUFLLENBQUMvQixFQUFOLENBQVMsYUFBVCxFQUF3QixLQUFLNEQsa0JBQUwsQ0FBd0JDLElBQXhCLENBQTZCLElBQTdCLENBQXhCO0lBRUEsT0FBTzlCLEtBQVA7RUFDSCxDQXZLSTtFQXlLTFMsaUJBektLLDZCQXlLYVQsS0F6S2IsRUF5S29CO0lBQ3JCQSxLQUFLLENBQUN1QixZQUFOLENBQW1CdkYsRUFBRSxDQUFDa0QsU0FBdEIsRUFBaUNyQyxJQUFqQyxHQUF3Q2IsRUFBRSxDQUFDbUQsYUFBSCxDQUFpQjRDLE9BQXpEO0lBQ0EsSUFBTUMscUJBQXFCLEdBQUdoQyxLQUFLLENBQUN1QixZQUFOLENBQW1CdkYsRUFBRSxDQUFDeUYscUJBQXRCLENBQTlCO0lBQ0FPLHFCQUFxQixDQUFDTixNQUF0QixHQUErQjFCLEtBQUssQ0FBQ2pCLE1BQU4sR0FBZSxDQUE5QztJQUNBaUQscUJBQXFCLENBQUNDLEtBQXRCO0VBQ0gsQ0E5S0k7RUFnTEw7RUFDQW5DLGdCQWpMSyw0QkFpTFlSLENBakxaLEVBaUxlQyxDQWpMZixFQWlMa0IxQyxJQWpMbEIsRUFpTDRCO0lBQUEsSUFBVkEsSUFBVTtNQUFWQSxJQUFVLEdBQUgsQ0FBRztJQUFBOztJQUM3QixJQUFNbUQsS0FBSyxHQUFHLEtBQUttQixjQUFMLENBQW9CdEUsSUFBcEIsQ0FBZDtJQUNBbUQsS0FBSyxDQUFDa0MsV0FBTixDQUFrQmxHLEVBQUUsQ0FBQzJDLEVBQUgsQ0FBTVcsQ0FBTixFQUFTQyxDQUFULENBQWxCO0lBQ0EsT0FBT1MsS0FBUDtFQUNILENBckxJO0VBc0xMO0VBQ0E2QixrQkF2TEssb0NBdUwrQjtJQUFBLElBQWZNLElBQWUsUUFBZkEsSUFBZTtJQUFBLElBQVRDLEtBQVMsUUFBVEEsS0FBUztJQUNoQ0EsS0FBSyxDQUFDcEUsSUFBTixDQUFXcUUsR0FBWCxDQUFlLGFBQWYsRUFEZ0MsQ0FDRjs7SUFFOUIsSUFBTWpHLEVBQUUsR0FBR2dHLEtBQUssQ0FBQ2IsWUFBTixDQUFtQixPQUFuQixFQUE0Qm5GLEVBQXZDLENBSGdDLENBSWhDOztJQUNBK0YsSUFBSSxDQUFDbkUsSUFBTCxDQUFVc0UsZ0JBQVYsQ0FBMkIsS0FBM0I7SUFDQUYsS0FBSyxDQUFDcEUsSUFBTixDQUFXc0UsZ0JBQVgsQ0FBNEIsS0FBNUI7SUFFQSxrQkFBaUJGLEtBQUssQ0FBQ3BFLElBQXZCO0lBQUEsSUFBUXNCLENBQVIsZUFBUUEsQ0FBUjtJQUFBLElBQVdDLENBQVgsZUFBV0EsQ0FBWDtJQUVBLEtBQUtnRCxnQkFBTCxDQUFzQm5HLEVBQXRCLEVBQTBCSixFQUFFLENBQUMyQyxFQUFILENBQU07TUFBRVcsQ0FBQyxFQUFEQSxDQUFGO01BQUtDLENBQUMsRUFBREE7SUFBTCxDQUFOLENBQTFCLEVBQTJDNkMsS0FBSyxDQUFDcEUsSUFBTixDQUFXYyxLQUF0RDtJQUVBLElBQU02QixNQUFNLEdBQUd2RSxFQUFFLEdBQUcsQ0FBcEI7O0lBQ0EsSUFBSXVFLE1BQU0sSUFBSSxFQUFkLEVBQWtCO01BQ2QsSUFBTTZCLFFBQVEsR0FBRyxLQUFLMUMsZ0JBQUwsQ0FBc0JSLENBQXRCLEVBQXlCQyxDQUF6QixFQUE0Qm9CLE1BQTVCLENBQWpCLENBRGMsQ0FFZDs7TUFDQSxLQUFLN0MsUUFBTCxJQUFpQjZDLE1BQU0sR0FBRyxFQUExQjtNQUNBLEtBQUtyRCxLQUFMLENBQVdtRixNQUFYLGNBQTZCLEtBQUszRSxRQUFsQyxDQUpjLENBS2Q7O01BQ0EsS0FBSzJDLGlCQUFMLENBQXVCK0IsUUFBdkIsRUFOYyxDQVFkOztNQUNBQSxRQUFRLENBQUNaLEtBQVQsR0FBaUIsQ0FBakI7TUFDQTVGLEVBQUUsQ0FBQzBHLEtBQUgsQ0FBU0YsUUFBVCxFQUFtQkcsRUFBbkIsQ0FBc0IsRUFBdEIsRUFBMEI7UUFDdEJmLEtBQUssRUFBRTtNQURlLENBQTFCLEVBRUc7UUFDQ3RCLE1BQU0sRUFBRTtNQURULENBRkgsRUFJR3NDLEtBSkg7SUFLSCxDQWZELE1BZU87TUFDSDtNQUNBOUIsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWjtJQUNIO0VBQ0osQ0F2Tkk7RUF5Tkw7RUFDQXdCLGdCQTFOSyw0QkEwTlluRyxFQTFOWixFQTBOZ0I2RCxHQTFOaEIsRUEwTnFCNEMsQ0ExTnJCLEVBME53QjtJQUN6QjtJQUNBN0csRUFBRSxDQUFDOEcsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUs3RixTQUF6QixFQUFvQyxLQUFwQyxFQUEyQyxDQUEzQztJQUNBbEIsRUFBRSxDQUFDOEcsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUsxRixVQUF6QixFQUFxQyxLQUFyQyxFQUE0QyxDQUE1QyxFQUh5QixDQUt6Qjs7SUFDQSxJQUFJMkYsS0FBSyxHQUFHaEgsRUFBRSxDQUFDcUYsV0FBSCxDQUFlLEtBQUtwRSxXQUFwQixDQUFaO0lBQ0EsS0FBS2UsSUFBTCxDQUFVMkQsUUFBVixDQUFtQnFCLEtBQW5CO0lBRUEsSUFBTTFCLE1BQU0sR0FBRyxLQUFLeEUsTUFBTCxDQUFZVixFQUFFLEdBQUcsQ0FBakIsQ0FBZjtJQUNBLElBQU1rQyxRQUFRLEdBQUcwRSxLQUFLLENBQUN6QixZQUFOLENBQW1CLE9BQW5CLENBQWpCO0lBQ0FqRCxRQUFRLENBQUNrRCxJQUFULENBQWNGLE1BQWQ7SUFDQWhELFFBQVEsQ0FBQzJFLFNBQVQsQ0FBbUJoRCxHQUFuQixFQUF3QjRDLENBQXhCO0VBQ0gsQ0F2T0k7RUF5T0xLLFFBek9LLHNCQXlPTTtJQUNQLEtBQUsxRixJQUFMLENBQVUyRixNQUFWLEdBQW1CLElBQW5CO0lBQ0EsS0FBSzNGLElBQUwsQ0FBVTRGLE1BQVYsR0FBbUIsQ0FBbkI7RUFDSDtBQTVPSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBGcnVpdCA9IGNjLkNsYXNzKHtcbiAgICBuYW1lOiAnRnJ1aXRJdGVtJyxcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGlkOiAwLFxuICAgICAgICBpY29uU0Y6IGNjLlNwcml0ZUZyYW1lXG4gICAgfVxufSk7XG5cbmNvbnN0IEp1aWNlSXRlbSA9IGNjLkNsYXNzKHtcbiAgICBuYW1lOiAnSnVpY2VJdGVtJyxcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHBhcnRpY2xlOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgY2lyY2xlOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgc2xhc2g6IGNjLlNwcml0ZUZyYW1lLFxuICAgIH1cbn0pO1xuXG4vLyBtb2R1bGUuZXhwb3J0cyA9IHRoaXM7XG5cblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgZnJ1aXRzOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcbiAgICAgICAgICAgIHR5cGU6IEZydWl0XG4gICAgICAgIH0sXG5cbiAgICAgICAganVpY2VzOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcbiAgICAgICAgICAgIHR5cGU6IEp1aWNlSXRlbVxuICAgICAgICB9LFxuXG4gICAgICAgIC8vIOWKqOaAgeeUn+aIkCDmib7liLDmibnph4/lpITnkIbpooTnva7lhYPntKDnmoTmlrnmoYhcbiAgICAgICAgZnJ1aXRQcmVmYWI6IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWJcbiAgICAgICAgfSxcblxuICAgICAgICBqdWljZVByZWZhYjoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYlxuICAgICAgICB9LFxuXG4gICAgICAgIC8vIHRvZG8g5Y+v5Lul5a6e546w5LiA5LiqYXVkaW9NYW5hZ2VyXG4gICAgICAgIGJvb21BdWRpbzoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuICAgICAgICBrbm9ja0F1ZGlvOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuQXVkaW9DbGlwXG4gICAgICAgIH0sXG4gICAgICAgIHdhdGVyQXVkaW86IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXBcbiAgICAgICAgfSxcblxuICAgICAgICBzY29yZToge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkxhYmVsXG4gICAgICAgIH0sXG5cbiAgICAgICAgbWFzazoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMuaW5pdFBoeXNpY3MoKTtcbiAgICAgICAgdGhpcy5pc0NyZWF0aW5nID0gZmFsc2U7XG4gICAgICAgIHRoaXMuZnJ1aXRDb3VudCA9IDA7XG4gICAgICAgIHRoaXMuc2NvcmVOdW0gPSAwO1xuICAgICAgICB0aGlzLmZydWl0c0xpc3QgPSBbXTtcbiAgICAgICAgLy8g55uR5ZCs54K55Ye75LqL5Lu2IHRvZG8g5piv5ZCm6IO95aSf5rOo5YaM5YWo5bGA5LqL5Lu2XG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xuXG4gICAgICAgIHRoaXMuaW5pdE9uZUZydWl0KCk7XG4gICAgfSxcblxuICAgIC8vIOW8gOWQr+eJqeeQhuW8leaTjuWSjOeisOaSnuajgOa1i1xuICAgIGluaXRQaHlzaWNzKCkge1xuICAgICAgICAvLyDniannkIblvJXmk45cbiAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpO1xuICAgICAgICBpbnN0YW5jZS5lbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgLy8gaW5zdGFuY2UuZGVidWdEcmF3RmxhZ3MgPSA0XG4gICAgICAgIGluc3RhbmNlLmdyYXZpdHkgPSBjYy52MigwLCAtOTYwKTtcblxuICAgICAgICAvLyDnorDmkp7mo4DmtYtcbiAgICAgICAgY29uc3QgY29sbGlzaW9uTWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKTtcbiAgICAgICAgY29sbGlzaW9uTWFuYWdlci5lbmFibGVkID0gdHJ1ZTtcblxuICAgICAgICAvLyDorr7nva7lm5vlkajnmoTnorDmkp7ljLrln59cbiAgICAgICAgbGV0IHdpZHRoID0gdGhpcy5ub2RlLndpZHRoO1xuICAgICAgICBsZXQgaGVpZ2h0ID0gdGhpcy5ub2RlLmhlaWdodDtcblxuICAgICAgICBsZXQgbm9kZSA9IG5ldyBjYy5Ob2RlKCk7XG5cbiAgICAgICAgbGV0IGJvZHkgPSBub2RlLmFkZENvbXBvbmVudChjYy5SaWdpZEJvZHkpO1xuICAgICAgICBib2R5LnR5cGUgPSBjYy5SaWdpZEJvZHlUeXBlLlN0YXRpYztcblxuICAgICAgICBjb25zdCBfYWRkQm91bmQgPSAobm9kZSwgeCwgeSwgd2lkdGgsIGhlaWdodCkgPT4ge1xuICAgICAgICAgICAgbGV0IGNvbGxpZGVyID0gbm9kZS5hZGRDb21wb25lbnQoY2MuUGh5c2ljc0JveENvbGxpZGVyKTtcbiAgICAgICAgICAgIGNvbGxpZGVyLm9mZnNldC54ID0geDtcbiAgICAgICAgICAgIGNvbGxpZGVyLm9mZnNldC55ID0geTtcbiAgICAgICAgICAgIGNvbGxpZGVyLnNpemUud2lkdGggPSB3aWR0aDtcbiAgICAgICAgICAgIGNvbGxpZGVyLnNpemUuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICB9XG5cbiAgICAgICAgX2FkZEJvdW5kKG5vZGUsIDAsIC1oZWlnaHQgLyAyLCB3aWR0aCwgMSk7XG4gICAgICAgIF9hZGRCb3VuZChub2RlLCAwLCBoZWlnaHQgLyAyLCB3aWR0aCwgMSk7XG4gICAgICAgIF9hZGRCb3VuZChub2RlLCAtd2lkdGggLyAyLCAwLCAxLCBoZWlnaHQpO1xuICAgICAgICBfYWRkQm91bmQobm9kZSwgd2lkdGggLyAyLCAwLCAxLCBoZWlnaHQpO1xuXG4gICAgICAgIG5vZGUucGFyZW50ID0gdGhpcy5ub2RlO1xuICAgIH0sXG5cbiAgICBpbml0T25lRnJ1aXQoaWQgPSAxKSB7XG4gICAgICAgIHRoaXMuZnJ1aXRDb3VudCsrO1xuICAgICAgICB0aGlzLmN1cnJlbnRGcnVpdCA9IHRoaXMuY3JlYXRlRnJ1aXRPblBvcygwLCA0MDAsIGlkKTtcbiAgICB9LFxuXG4gICAgLy8g55uR5ZCs5bGP5bmV54K55Ye7XG4gICAgb25Ub3VjaFN0YXJ0KGUpIHtcbiAgICAgICAgaWYgKHRoaXMuaXNDcmVhdGluZykgcmV0dXJuO1xuICAgICAgICB0aGlzLmlzQ3JlYXRpbmcgPSB0cnVlO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIjU1NTU1NTU1NTU1NTU1NTU1XCIpXG4gICAgICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCB9ID0gdGhpcy5ub2RlO1xuXG4gICAgICAgIGNvbnN0IGZydWl0ID0gdGhpcy5jdXJyZW50RnJ1aXQ7XG5cbiAgICAgICAgY29uc3QgcG9zID0gZS5nZXRMb2NhdGlvbigpO1xuICAgICAgICBsZXQgeyB4LCB5IH0gPSBwb3M7XG4gICAgICAgIHggPSB4IC0gd2lkdGggLyAyO1xuICAgICAgICB5ID0geSAtIGhlaWdodCAvIDI7XG5cbiAgICAgICAgY29uc3QgYWN0aW9uID0gY2Muc2VxdWVuY2UoY2MubW92ZUJ5KDAuMywgY2MudjIoeCwgMCkpLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25JbigpKSwgY2MuY2FsbEZ1bmMoKCkgPT4ge1xuICAgICAgICAgICAgLy8g5byA5ZCv54mp55CG5pWI5p6cXG4gICAgICAgICAgICB0aGlzLnN0YXJ0RnJ1aXRQaHlzaWNzKGZydWl0KTtcblxuICAgICAgICAgICAgLy8gMXPlkI7ph43mlrDnlJ/miJDkuIDkuKpcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKCgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0SWQgPSB0aGlzLmdldE5leHRGcnVpdElkKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5pbml0T25lRnJ1aXQobmV4dElkKTtcbiAgICAgICAgICAgICAgICB0aGlzLmlzQ3JlYXRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIjk5OTk5OTk5OTk5OTk5OTk5OTlcIilcblxuICAgICAgICAgICAgfSwgMSlcbiAgICAgICAgfSkpXG5cbiAgICAgICAgZnJ1aXQucnVuQWN0aW9uKGFjdGlvbik7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuY3VycmVudEZydWl0LmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lLm5hbWUpXG4gICAgICAgIGNvbnNvbGUubG9nKHRoaXMuY3VycmVudEZydWl0Lm5hbWUpXG4gICAgfSxcbiAgICAvLyDojrflj5bkuIvkuIDkuKrmsLTmnpznmoRpZFxuICAgIGdldE5leHRGcnVpdElkKCkge1xuICAgICAgICBpZiAodGhpcy5mcnVpdENvdW50IDwgMykge1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5mcnVpdENvdW50ID09PSAzKSB7XG4gICAgICAgICAgICByZXR1cm4gMjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIOmaj+acuui/lOWbnuWJjTXkuKpcbiAgICAgICAgICAgIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1KSArIDE7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vIOWIm+W7uuS4gOS4quawtOaenFxuICAgIGNyZWF0ZU9uZUZydWl0KG51bSkge1xuICAgICAgICBsZXQgZnJ1aXQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmZydWl0UHJlZmFiKTtcbiAgICAgICAgY29uc3QgY29uZmlnID0gdGhpcy5mcnVpdHNbbnVtIC0gMV07XG5cbiAgICAgICAgZnJ1aXQuZ2V0Q29tcG9uZW50KCdGcnVpdCcpLmluaXQoe1xuICAgICAgICAgICAgaWQ6IGNvbmZpZy5pZCxcbiAgICAgICAgICAgIGljb25TRjogY29uZmlnLmljb25TRlxuICAgICAgICB9KTtcblxuICAgICAgICBmcnVpdC5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS50eXBlID0gY2MuUmlnaWRCb2R5VHlwZS5TdGF0aWM7XG4gICAgICAgIGZydWl0LmdldENvbXBvbmVudChjYy5QaHlzaWNzQ2lyY2xlQ29sbGlkZXIpLnJhZGl1cyA9IDA7XG5cbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKGZydWl0KTtcbiAgICAgICAgZnJ1aXQuc2NhbGUgPSAwLjY7XG5cbiAgICAgICAgLy8g5pyJRnJ1aXTnu4Tku7bkvKDlhaVcbiAgICAgICAgZnJ1aXQub24oJ3NhbWVDb250YWN0JywgdGhpcy5vblNhbWVGcnVpdENvbnRhY3QuYmluZCh0aGlzKSk7XG5cbiAgICAgICAgcmV0dXJuIGZydWl0O1xuICAgIH0sXG5cbiAgICBzdGFydEZydWl0UGh5c2ljcyhmcnVpdCkge1xuICAgICAgICBmcnVpdC5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS50eXBlID0gY2MuUmlnaWRCb2R5VHlwZS5EeW5hbWljO1xuICAgICAgICBjb25zdCBwaHlzaWNzQ2lyY2xlQ29sbGlkZXIgPSBmcnVpdC5nZXRDb21wb25lbnQoY2MuUGh5c2ljc0NpcmNsZUNvbGxpZGVyKTtcbiAgICAgICAgcGh5c2ljc0NpcmNsZUNvbGxpZGVyLnJhZGl1cyA9IGZydWl0LmhlaWdodCAvIDI7XG4gICAgICAgIHBoeXNpY3NDaXJjbGVDb2xsaWRlci5hcHBseSgpO1xuICAgIH0sXG5cbiAgICAvLyDlnKjmjIflrprkvY3nva7nlJ/miJDmsLTmnpxcbiAgICBjcmVhdGVGcnVpdE9uUG9zKHgsIHksIHR5cGUgPSAxKSB7XG4gICAgICAgIGNvbnN0IGZydWl0ID0gdGhpcy5jcmVhdGVPbmVGcnVpdCh0eXBlKTtcbiAgICAgICAgZnJ1aXQuc2V0UG9zaXRpb24oY2MudjIoeCwgeSkpO1xuICAgICAgICByZXR1cm4gZnJ1aXQ7XG4gICAgfSxcbiAgICAvLyDkuKTkuKrmsLTmnpznorDmkp5cbiAgICBvblNhbWVGcnVpdENvbnRhY3QoeyBzZWxmLCBvdGhlciB9KSB7XG4gICAgICAgIG90aGVyLm5vZGUub2ZmKCdzYW1lQ29udGFjdCcpIC8vIOS4pOS4qm5vZGXpg73kvJrop6blj5HvvIx0b2RvIOeci+eci+acieayoeacieWFtuS7luaWueazleWPquWxleekuuS4gOasoeeahFxuXG4gICAgICAgIGNvbnN0IGlkID0gb3RoZXIuZ2V0Q29tcG9uZW50KCdGcnVpdCcpLmlkO1xuICAgICAgICAvLyB0b2RvIOWPr+S7peS9v+eUqOWvueixoeaxoOWbnuaUtlxuICAgICAgICBzZWxmLm5vZGUucmVtb3ZlRnJvbVBhcmVudChmYWxzZSk7XG4gICAgICAgIG90aGVyLm5vZGUucmVtb3ZlRnJvbVBhcmVudChmYWxzZSk7XG5cbiAgICAgICAgY29uc3QgeyB4LCB5IH0gPSBvdGhlci5ub2RlO1xuXG4gICAgICAgIHRoaXMuY3JlYXRlRnJ1aXRKdWljZShpZCwgY2MudjIoeyB4LCB5IH0pLCBvdGhlci5ub2RlLndpZHRoKTtcblxuICAgICAgICBjb25zdCBuZXh0SWQgPSBpZCArIDE7XG4gICAgICAgIGlmIChuZXh0SWQgPD0gMTEpIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0ZydWl0ID0gdGhpcy5jcmVhdGVGcnVpdE9uUG9zKHgsIHksIG5leHRJZCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhuZXdGcnVpdCk7XG4gICAgICAgICAgICB0aGlzLnNjb3JlTnVtICs9IG5leHRJZCAqIDEwO1xuICAgICAgICAgICAgdGhpcy5zY29yZS5zdHJpbmcgPSBgU2NvcmU6JHt0aGlzLnNjb3JlTnVtfWA7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhuZXdGcnVpdC5nZXRDb21wb25lbnQoXCJGcnVpdFwiKS5pZCk7XG4gICAgICAgICAgICB0aGlzLnN0YXJ0RnJ1aXRQaHlzaWNzKG5ld0ZydWl0KTtcblxuICAgICAgICAgICAgLy8g5bGV56S65Yqo55S7IHRvZG8g5Yqo55S75pWI5p6c6ZyA6KaB6LCD5pW0XG4gICAgICAgICAgICBuZXdGcnVpdC5zY2FsZSA9IDA7XG4gICAgICAgICAgICBjYy50d2VlbihuZXdGcnVpdCkudG8oLjUsIHtcbiAgICAgICAgICAgICAgICBzY2FsZTogMC42XG4gICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgZWFzaW5nOiBcImJhY2tPdXRcIlxuICAgICAgICAgICAgfSkuc3RhcnQoKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gdG9kbyDlkIjmiJDkuKTkuKropb/nk5xcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCcgdG9kbyDlkIjmiJDkuKTkuKropb/nk5wnKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvLyDlkIjlubbml7bnmoTliqjnlLvmlYjmnpxcbiAgICBjcmVhdGVGcnVpdEp1aWNlKGlkLCBwb3MsIG4pIHtcbiAgICAgICAgLy8g5pKt5pS+5ZCI5bm255qE5aOw6Z+zXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5ib29tQXVkaW8sIGZhbHNlLCAxKTtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLndhdGVyQXVkaW8sIGZhbHNlLCAxKTtcblxuICAgICAgICAvLyDlsZXnpLrliqjnlLtcbiAgICAgICAgbGV0IGp1aWNlID0gY2MuaW5zdGFudGlhdGUodGhpcy5qdWljZVByZWZhYik7XG4gICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZChqdWljZSk7XG5cbiAgICAgICAgY29uc3QgY29uZmlnID0gdGhpcy5qdWljZXNbaWQgLSAxXTtcbiAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBqdWljZS5nZXRDb21wb25lbnQoJ0p1aWNlJyk7XG4gICAgICAgIGluc3RhbmNlLmluaXQoY29uZmlnKTtcbiAgICAgICAgaW5zdGFuY2Uuc2hvd0p1aWNlKHBvcywgbik7XG4gICAgfSxcblxuICAgIGdhbWVvdmVyKCkge1xuICAgICAgICB0aGlzLm1hc2suYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5tYXNrLnpJbmRleCA9IDE7XG4gICAgfVxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------
