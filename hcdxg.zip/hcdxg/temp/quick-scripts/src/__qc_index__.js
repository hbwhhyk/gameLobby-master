
require('./assets/scripts/Fruit');
require('./assets/scripts/Game');
require('./assets/scripts/Juice');
require('./assets/scripts/Load');
require('./assets/scripts/Over');
