const Game = require("Game");

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },

        best: cc.Label,
        score: cc.Label,

        game: Game
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad() {

    // },

    start() {

        this.showScore();
    },

    onBtnClick() {
        cc.director.loadScene("game");
    },

    showScore() {
        this.score.string = `Score:${this.game.scoreNum}`;
        let bestScore = Number(cc.sys.localStorage.getItem('hcdxg'));
        if (!bestScore) {
            this.best.string = `Best:${this.game.scoreNum}`;
            cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
        } else {
            if (bestScore < this.game.scoreNum) {
                this.best.string = `Best:${this.game.scoreNum}`;
                cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
            } else {
                this.best.string = `Best:${bestScore}`;
            }
        }
    }

    // update (dt) {},
});
