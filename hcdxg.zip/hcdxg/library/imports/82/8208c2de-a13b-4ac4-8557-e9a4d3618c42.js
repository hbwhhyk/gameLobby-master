"use strict";
cc._RF.push(module, '8208cLeoTtKxIVX6aTTYYxC', 'Over');
// scripts/Over.js

"use strict";

var Game = require("Game");

cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    best: cc.Label,
    score: cc.Label,
    game: Game
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad() {
  // },
  start: function start() {
    this.showScore();
  },
  onBtnClick: function onBtnClick() {
    cc.director.loadScene("game");
  },
  showScore: function showScore() {
    this.score.string = "Score:" + this.game.scoreNum;
    var bestScore = Number(cc.sys.localStorage.getItem('hcdxg'));

    if (!bestScore) {
      this.best.string = "Best:" + this.game.scoreNum;
      cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
    } else {
      if (bestScore < this.game.scoreNum) {
        this.best.string = "Best:" + this.game.scoreNum;
        cc.sys.localStorage.setItem('hcdxg', this.game.scoreNum);
      } else {
        this.best.string = "Best:" + bestScore;
      }
    }
  } // update (dt) {},

});

cc._RF.pop();