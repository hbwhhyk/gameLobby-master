"use strict";
cc._RF.push(module, '365b4UAiQRBA7QXa2IuFMmj', 'Fruit');
// scripts/Fruit.js

"use strict";

// const Game = require("Game");
cc.Class({
  "extends": cc.Component,
  properties: {
    id: 0 // game: Game

  },
  init: function init(data) {
    this.id = data.id;
    var sp = this.node.getComponent(cc.Sprite);
    sp.spriteFrame = data.iconSF; // todo 控制一下每种水果的尺寸
  },
  start: function start() {},
  onBeginContact: function onBeginContact(contact, self, other) {
    // 貌似检测有点消耗性能
    if (self.node && other.node) {
      var s = self.node.getComponent('Fruit');
      var o = other.node.getComponent('Fruit');

      if (s && o && s.id === o.id) {
        self.node.emit('sameContact', {
          self: self,
          other: other
        });
      }
    }
  },
  update: function update() {
    // console.log(111)
    if (!this.node.getComponent(cc.RigidBody).awake && this.node.y >= cc.find("Canvas/xuxian").y) {
      cc.find("Canvas").getComponent("Game").gameover();
    }
  }
});

cc._RF.pop();